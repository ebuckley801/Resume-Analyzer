# resume_matcher_services/security.py
from datetime import datetime
import re
from werkzeug.security import generate_password_hash, check_password_hash

def hash_password(password):
    """Hash a password using Werkzeug security"""
    return generate_password_hash(password)

def verify_password(password_hash, password):
    """Verify a password against a hash using Werkzeug security"""
    return check_password_hash(password_hash, password)

def validate_password_strength(password):
    """
    Validate password strength:
    - At least 8 characters
    - Contains at least one uppercase letter
    - Contains at least one lowercase letter
    - Contains at least one number
    - Contains at least one special character
    """
    if len(password) < 8:
        return False, "Password must be at least 8 characters long."
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter."
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter."
    
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number."
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "Password must contain at least one special character."
    
    return True, "Password is strong."

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(pattern, email):
        return True
    return False

def validate_password_complexity(password):
    """Alias for validate_password_strength for API consistency"""
    is_valid, _ = validate_password_strength(password)
    return is_valid

def get_password_rules():
    """Return password requirements for client-side validation"""
    return {
        "min_length": 8,
        "require_uppercase": True,
        "require_lowercase": True,
        "require_number": True,
        "require_special": True,
        "special_chars": "!@#$%^&*(),.?\":{}|<>"
    }