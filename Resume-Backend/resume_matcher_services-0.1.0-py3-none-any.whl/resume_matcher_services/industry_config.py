# services/industry_config.py
from typing import Dict, List, Set, Tuple, Optional
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from collections import defaultdict
import logging
import re
from .shared_utilities import (
    SKILL_CATEGORIES,
    SECTION_SYNONYMS,
    INDUSTRY_SYNONYMS,
    INDUSTRY_CONFIGS
)

logger = logging.getLogger(__name__)


class IndustryConfig:
    def __init__(
            self,
            name: str,
            required_sections: List[str],
            section_weights: Dict[str, float],
            keywords: List[str],
            skill_categories: Dict[str, List[str]],
            experience_patterns: List[str],
            transferable_skills: Optional[Dict[str, float]] = None
    ):
        self.name = name
        # Normalize required sections to canonical form using SECTION_SYNONYMS
        self.required_sections = [SECTION_SYNONYMS.get(s.lower(), s.lower()) for s in required_sections]
        self.section_weights = section_weights
        self.keywords = keywords
        self.skill_categories = skill_categories
        self.experience_patterns = experience_patterns
        # New: transferable skills with relevance scores
        self.transferable_skills = transferable_skills or {}


class IndustryDetector:
    """
    A comprehensive industry detection system that uses multiple strategies
    to accurately classify job descriptions and resumes.

    Strategies include:
    1. Job title pattern matching
    2. Industry-specific keyword counting
    3. TF-IDF similarity calculation
    4. Experience pattern matching
    5. NEW: Cross-industry skill mapping for transferable skills
    """

    def __init__(self):
        try:
            # Try to import sentence transformers, but don't require it
            from sentence_transformers import SentenceTransformer, util
            self.sentence_transformer = SentenceTransformer('all-MiniLM-L6-v2')
            self.util = util
            self.use_embeddings = True
        except (ImportError, Exception) as e:
            logger.warning(f"Sentence transformer not available, falling back to TF-IDF: {str(e)}")
            self.use_embeddings = False

        self.vectorizer = TfidfVectorizer(stop_words='english')

        # Initialize industry profiles
        self.industry_profiles = {}
        self.job_title_patterns = self._compile_job_title_patterns()
        self._initialize_industry_profiles()

        # NEW: Create a mapping of skills between related industries
        self._build_cross_industry_skill_map()

    def _compile_job_title_patterns(self) -> Dict[str, re.Pattern]:
        """
        Compile regular expressions for job title matching, extended based on shared_utilities.txt.

        Returns:
            Dict[str, re.Pattern]: A dictionary where keys are industry/category names
                                   and values are compiled regex patterns.
        """
        patterns = {
            'technology': re.compile(
                r'\b('
                # Roles
                r'software|web|frontend|backend|full[ -]?stack|devops|cloud|data|database|network|security|systems?'
                r'|it|technical|application|qa|quality assurance|automation|mobile|embedded'
                r'|ai|artificial intelligence|machine learning|ml|nlp|natural language processing'
                r'|sre|site reliability|platform'
                r')\s+'
                r'(developer|engineer|architect|programmer|scientist|analyst|specialist|consultant|administrator|admin|support|technician|lead|manager)'
                r'\b|\b(tech|developer|programmer|coder|software engineer|swe|data scientist|dba|cloud engineer|devops engineer|security analyst)\b',
                re.IGNORECASE),

            # Broad Engineering category combining keywords from the file
            'engineering': re.compile(
                r'\b('
                # Fields
                r'civil|structural|mechanical|electrical|chemical|biomedical|environmental|industrial|aerospace|systems?'
                r'|manufacturing|process|design|quality|reliability|test|automation|robotics|hardware|materials|project'
                r')\s+'
                # Roles
                r'(engineer|technician|designer|drafter|specialist|manager|consultant|supervisor|inspector|planner|lead)'
                r'\b|\b(engineering|engineer|eng|cad|cam|plm|scada|mes|hvac)\b',
                re.IGNORECASE),

            # Specific Engineering Fields (can be added if more granularity is needed, using synonyms from the file [cite: 55, 56, 57, 58])
            'civil_engineering': re.compile(
                r'\b(civil|structural|construction|transportation|environmental|water|geotechnical)\s+'
                r'(engineer|manager|designer|planner|consultant|supervisor|inspector|technician)\b'
                r'|\b(ce|civil eng|structural eng|geotechnical eng|transportation eng|water resources eng|construction mgmt)\b',
                re.IGNORECASE),

            'electrical_engineering': re.compile(
                r'\b(electrical|electronics|power|systems?|control|communications|hardware|embedded|automation)\s+'
                r'(engineer|technician|designer|specialist)\b'
                r'|\b(ee|electrical eng|electronics eng|power systems eng|embedded systems eng|control systems eng|automation eng)\b',
                re.IGNORECASE),

            'mechanical_engineering': re.compile(
                r'\b(mechanical|thermodynamics|fluid dynamics|hvac|manufacturing|materials|robotics)\s+'
                r'(engineer|technician|designer|specialist|drafter)\b'
                r'|\b(mech eng|mechanical eng|materials sci|fluid dynamics|thermodynamics|robotics eng|hvac eng|manufacturing eng)\b',
                re.IGNORECASE),

            'healthcare': re.compile(
                r'\b('
                # Roles/Keywords
                r'doctor|physician|surgeon|nurse|rn|lpn|cna|medical|clinical|healthcare|patient|pharma(?:ceutical)?|biotech|hospital'
                r'|therapist|technician|assistant|practitioner|dental|hygienist|pharmacist|optometrist|veterinarian'
                r'|emr|ehr|hipaa|telehealth|telemed|medtech|crc'
                r')\s*'
                # Optional secondary role/descriptor
                r'(assistant|technician|specialist|consultant|manager|administrator|coordinator|researcher|scientist)?'
                r'\b|\b(md|do|np|pa|healthcare|medical|clinical|pharma|biotech|healthtech)\b',
                re.IGNORECASE),

            'finance': re.compile(
                r'\b('
                # Roles/Keywords
                r'financial|finance|accountant|accounting|auditor|banking|investment|broker|trader|analyst|portfolio|risk|compliance'
                r'|underwriter|actuary|controller|treasurer|cfo|planner|advisor|wealth|asset|fund|quantitative|quant'
                r'|cfa|cpa|fintech|crypto|defi|valuation|modeling|budgeting'
                r')\s*'
                # Optional secondary role/descriptor
                r'(analyst|manager|specialist|consultant|advisor|associate|director|planner|officer)?'
                r'\b|\b(finance|fintech|cfa|cpa|accounting|audit|investment|banking)\b',
                re.IGNORECASE),

            'legal': re.compile(
                r'\b(attorney|lawyer|legal|paralegal|counsel|compliance|regulatory|contract|patent|litigation|judicial|clerk|judge)\s*'
                r'(assistant|specialist|manager|consultant|officer|secretary|clerk)?'
                r'\b|\b(legal|law|jd|esquire|legaltech)\b',
                re.IGNORECASE),

            'education': re.compile(
                r'\b('
                # Roles/Keywords
                r'teacher|professor|instructor|educator|principal|dean|academic|faculty|school|university|college|tutor'
                r'|curriculum|pedagogy|instructional|training|learning|librarian|admissions|advisor|counselor'
                r'|lms|edtech|elearn|k12|higher ed'
                r')\s*'
                # Optional secondary role/descriptor
                r'(developer|designer|specialist|coordinator|manager|assistant|aide|administrator|director)?'
                r'\b|\b(education|teaching|instructor|professor|edtech|lms)\b',
                re.IGNORECASE),

            'creative': re.compile(
                r'\b('
                # Roles/Keywords
                r'designer|artist|writer|creative|content|ux|ui|graphic|brand|marketing|media|production|editor|illustrator'
                r'|photographer|animator|video|producer|director|copywriter|journalist|musician|actor|dancer|architect'  # Architect can overlap, context matters
                r'|ui/ux|uxd|cgi|mograph|vidprod'
                r')\s*'
                # Optional secondary role/descriptor
                r'(designer|developer|specialist|manager|director|lead|strategist|assistant|coordinator|producer|editor)?'
                r'\b|\b(creative|design|art|writing|media|marketing|ui|ux|graphic design|content)\b',
                re.IGNORECASE),

            'business': re.compile(
                r'\b('
                # Roles/Keywords
                r'business|marketing|sales|operations|management|strategy|product|project|program|executive|director|manager'
                r'|consultant|administrator|coordinator|assistant|support|analyst|hr|human resources|recruiter|talent'
                r'|customer|client|account|supply chain|logistics|purchasing|vendor|partner|ceo|coo|cto|cmo'
                r'|kpi|roi|b2b|b2c|crm|erp'
                r')\s*'
                # Optional secondary role/descriptor
                r'(manager|director|analyst|specialist|consultant|coordinator|assistant|executive|lead|developer|partner|representative|support)?'
                r'\b|\b(business|management|operations|sales|marketing|hr|strategy|product|project)\b',
                re.IGNORECASE),

            # Added Management category based on file [cite: 25, 26, 27]
            'management': re.compile(
                r'\b('
                r'manager|director|lead|supervisor|head|vp|vice president|president|executive|chief|principal'
                r'|project manager|product manager|program manager|operations manager|general manager|team lead'
                r'|pmp|agile|scrum'  # Certifications/methodologies often indicate management
                r')\b',
                re.IGNORECASE),

            # Added General/Admin category based on file [cite: 28, 29]
            'general_admin': re.compile(
                r'\b(admin|administrative|assistant|coordinator|support|clerk|receptionist|secretary|office manager|generalist|operations)\b',
                re.IGNORECASE),

            # Added Research/Science category
            'research_science': re.compile(
                r'\b(research|scientist|researcher|lab|laboratory|postdoc|fellow|analyst|chemist|physicist|biologist|statistician|mathematician|r&d)\s*'
                r'(assistant|technician|associate|manager|director|scientist|fellow)?'
                r'\b|\b(research|science|r&d|phd)\b',
                re.IGNORECASE),
        }
        return patterns

    def _initialize_industry_profiles(self):
        """Initialize industry profiles for similarity comparisons."""
        for industry, config in INDUSTRY_CONFIGS.items():
            # Combine keywords and experience patterns for a rich industry profile
            keywords = config.get('keywords', [])
            experience_patterns = config.get('experience_patterns', [])

            # Get all associated skills for this industry
            industry_skills = []
            skill_categories = SKILL_CATEGORIES.get(industry, {})
            for category, skills in skill_categories.items():
                if isinstance(skills, list):
                    industry_skills.extend(skills)
                elif isinstance(skills, dict):
                    for subcategory, subcategory_skills in skills.items():
                        industry_skills.extend(subcategory_skills)

            # Create the profile text
            profile_text = ' '.join(keywords + experience_patterns + industry_skills)

            # Store the profile text for later use
            self.industry_profiles[industry] = profile_text

    def _build_cross_industry_skill_map(self):
        """
        Build a mapping of transferable skills between industries.
        Each skill gets a relevance score (0-1) for each target industry.
        """
        self.cross_industry_skills = {}

        # Define generic transferable skills present in multiple industries
        generic_transferable = {
            # Communication skills
            "communication": 0.8,
            "presentation": 0.7,
            "technical writing": 0.7,
            "documentation": 0.7,

            # Analytical skills
            "problem solving": 0.8,
            "critical thinking": 0.8,
            "data analysis": 0.7,
            "research": 0.7,

            # Software/tools used across disciplines
            "microsoft office": 0.6,
            "excel": 0.6,
            "project management": 0.7,
            "python": 0.5,
            "sql": 0.5,

            # Management skills
            "leadership": 0.7,
            "team coordination": 0.7,
            "resource management": 0.6,
            "budgeting": 0.6
        }

        # Define industry-specific mappings for a broader range of fields
        specific_mappings = {
            # ==========================================
            # Technology -> Other Fields
            # ==========================================
            ("technology", "engineering"): {  # General Engineering
                "python": 0.7, "c++": 0.8, "java": 0.6, "matlab": 0.8, "linux": 0.6,
                "data analysis": 0.8, "simulation": 0.8, "modeling": 0.7, "algorithms": 0.7,
                "embedded systems": 0.8, "robotics": 0.7, "control systems": 0.6,
                "problem solving": 0.9, "technical documentation": 0.8, "testing": 0.7,
                "project management": 0.8, "agile": 0.7, "version control": 0.7,  # e.g., Git
                "cloud": 0.4,  # For IoT, data platforms
                "database management": 0.5,  # For sensor data, logs
                "networking": 0.5,  # Device connectivity
                "cad": 0.5,  # If tech role involved product design
                "visualization": 0.6,
                "communication": 0.7,  # General soft skill
                "teamwork": 0.8,  # General soft skill
            },
            ("technology", "construction"): {  # Specific subset of Engineering
                "project management": 0.9, "data analysis": 0.7, "simulation": 0.7,  # BIM etc.
                "documentation": 0.8, "gis": 0.8, "database management": 0.6,
                "problem solving": 0.8, "modeling": 0.7, "visualization": 0.6,
                "python": 0.6,  # Automation, scripting
                "networking": 0.5,  # Site setup, IoT
                "iot": 0.6,  # Smart building tech
                "autocad": 0.7, "revit": 0.7, "civil 3d": 0.7,  # If learned
                "communication": 0.7, "teamwork": 0.8,
            },
            ("technology", "manufacturing"): {  # Specific subset of Engineering
                "automation": 0.9, "robotics": 0.8, "embedded systems": 0.7, "python": 0.8,
                "project management": 0.8, "data analysis": 0.8, "testing": 0.7, "quality control": 0.8,
                "system integration": 0.7, "process optimization": 0.8, "database management": 0.6,  # MES, inventory
                "networking": 0.6,  # Factory networks
                "supply chain management": 0.5,  # If involved
                "lean manufacturing": 0.6, "six sigma": 0.6,  # Process improvement overlap
                "problem solving": 0.8, "communication": 0.7, "teamwork": 0.8,
            },
            ("technology", "finance"): {
                "python": 0.8, "java": 0.6, "c++": 0.7, "sql": 0.8, "excel": 0.8,  # Automation focus
                "data analysis": 0.9, "machine learning": 0.7, "statistical modeling": 0.8,
                "algorithms": 0.7, "database management": 0.7, "visualization": 0.7,
                "cloud": 0.5, "cybersecurity": 0.7, "risk management": 0.6,  # Tech risk -> Fin risk
                "problem solving": 0.8, "communication": 0.7,  # Explaining tech to finance
                "project management": 0.7, "quantitative analysis": 0.7,
            },
            ("technology", "healthcare"): {
                "python": 0.7, "sql": 0.7, "java": 0.5,
                "data analysis": 0.8, "machine learning": 0.6,  # Diagnostics, prediction
                "data security": 0.9,  # HIPAA
                "database management": 0.8,  # EHR/EMR
                "user interface design": 0.7, "user experience": 0.7,  # Medical software/devices
                "documentation": 0.7, "testing": 0.8,  # Rigorous validation
                "cloud": 0.6,  # Hosting systems
                "system integration": 0.7, "project management": 0.7, "networking": 0.6,
                "image processing": 0.7,  # Medical imaging
                "compliance": 0.8,  # HIPAA, FDA
                "problem solving": 0.8, "communication": 0.7,
            },
            ("technology", "business"): {
                "project management": 0.9, "agile methodologies": 0.8, "scrum": 0.8,
                "data analysis": 0.8, "visualization": 0.7,  # BI tools
                "problem solving": 0.8, "automation": 0.7,  # Business process automation
                "system design": 0.6,  # Designing business systems/workflows
                "cloud computing": 0.5, "database management": 0.6,  # Business databases
                "communication": 0.7,  # Bridging tech and business needs
                "documentation": 0.6, "testing": 0.5,  # UAT
                "strategy": 0.5,  # Tech strategy -> Business strategy
                "crm": 0.4, "erp": 0.4,  # Understanding the systems
                "leadership": 0.6,  # Tech lead -> Team lead
            },
            ("technology", "marketing"): {  # Subset of Business/Creative
                "data analysis": 0.8,  # Campaign analysis, web analytics
                "python": 0.6,  # Marketing automation scripts
                "sql": 0.6,  # Customer databases
                "user experience": 0.7,  # Website/app usability
                "user interface design": 0.7,
                "project management": 0.7,  # Campaign management
                "visualization": 0.7,  # Reporting dashboards
                "a/b testing": 0.8,  # Website/feature testing
                "seo": 0.5,  # Technical SEO
                "content management systems (cms)": 0.6,
                "problem solving": 0.7, "communication": 0.7,
            },
            ("technology", "legal"): {
                "data security": 0.8,  # Privacy, compliance
                "database management": 0.6,  # eDiscovery, case management
                "documentation": 0.7,  # Technical aspects of compliance
                "project management": 0.6,  # Implementing legal tech
                "cybersecurity": 0.7,
                "e-discovery": 0.8,  # Specific legal tech skill
                "compliance": 0.7,  # GDPR, CCPA etc.
                "risk assessment": 0.6,  # Tech risk
                "problem solving": 0.7, "communication": 0.6,
                "automation": 0.5,  # Automating legal workflows
            },
            ("technology", "education"): {  # EdTech roles, IT support
                "project management": 0.7,  # Implementing educational tech
                "user interface design": 0.6,  # Educational software
                "user experience": 0.6,
                "database management": 0.6,  # Student information systems
                "networking": 0.7,  # School networks
                "cybersecurity": 0.7,  # Protecting student data
                "cloud": 0.5,  # LMS hosting
                "documentation": 0.6,  # User guides, training
                "testing": 0.6,  # Testing educational software
                "problem solving": 0.8,  # Tech support
                "communication": 0.7,  # Training users
                "learning management systems (lms)": 0.8,  # Direct EdTech skill
            },
            ("technology", "creative"): {
                "user experience": 0.8, "user interface design": 0.8,  # Core overlap
                "project management": 0.6, "agile": 0.6,
                "design": 0.6,  # If tech person has design sensibility/skills
                "prototype development": 0.7,  # Software prototyping
                "problem solving": 0.7, "collaboration": 0.7,
                "python": 0.4,  # Scripting for creative tools (niche)
                "web development": 0.7,  # Frontend skills overlap
                "visualization": 0.5,
                "communication": 0.7,
            },
            ("technology", "management"): {
                "project management": 0.9, "agile": 0.9, "scrum": 0.9,
                "leadership": 0.7,  # Tech lead experience
                "strategy": 0.6,  # Technical strategy
                "problem solving": 0.8, "decision making": 0.7,  # Data-driven
                "process improvement": 0.7,  # Optimizing workflows
                "resource allocation": 0.6,  # Assigning tasks/people
                "risk management": 0.7,  # Project/technical risk
                "communication": 0.8,  # Communicating vision, status
                "budget management": 0.5,  # If involved in project budgets
                "teamwork": 0.8,
            },
            ("technology", "research_science"): {
                "python": 0.9,  # Data analysis, simulation, scripting
                "data analysis": 0.9, "machine learning": 0.7, "statistical modeling": 0.8,
                "simulation": 0.8, "modeling": 0.8,
                "database management": 0.7,  # Research data
                "linux": 0.7,  # Common in research computing
                "high performance computing (hpc)": 0.6,  # If applicable
                "visualization": 0.7,
                "algorithms": 0.7,
                "problem solving": 0.9, "documentation": 0.7,  # Research papers, code docs
                "version control": 0.7,  # Git for code/data
                "communication": 0.7,  # Presenting findings
            },
            # ==========================================
            # Engineering -> Other Fields
            # ==========================================
            ("engineering", "technology"): {
                "problem solving": 0.9, "analytical skills": 0.9,
                "project management": 0.8, "testing": 0.7, "documentation": 0.8,
                "simulation": 0.7, "modeling": 0.7,
                "python": 0.7, "c++": 0.7, "matlab": 0.6,  # Less common in pure SW dev
                "cad": 0.3,  # Generally not transferable to software roles unless specific hardware interface
                "embedded systems": 0.8,  # Direct overlap
                "control systems": 0.6,  # Overlap with automation/robotics SW
                "data analysis": 0.7,  # Engineering data -> general data analysis
                "linux": 0.6,
                "communication": 0.7, "teamwork": 0.8,
            },
            ("engineering", "management"): {
                "project management": 0.9, "leadership": 0.7,  # Leading eng teams/projects
                "problem solving": 0.8, "decision making": 0.8,  # Analytical approach
                "technical expertise": 0.8,  # Credibility in managing engineers
                "process optimization": 0.7, "risk assessment": 0.7,
                "planning": 0.8, "resource allocation": 0.7,  # Project resources
                "budget management": 0.6,  # Project budgets
                "communication": 0.7, "teamwork": 0.8,
                "quality control": 0.6, "safety management": 0.6,  # Depending on eng field
            },
            ("engineering", "business"): {
                "project management": 0.8, "problem solving": 0.8, "analytical skills": 0.8,
                "process optimization": 0.7, "data analysis": 0.6,
                "technical documentation": 0.6,  # -> Business documentation
                "risk assessment": 0.6,
                "supply chain management": 0.6,  # Esp. Industrial/Mechanical Eng
                "operations management": 0.7,  # Esp. Industrial/Manufacturing Eng
                "communication": 0.7,  # Explaining technical aspects
                "budget management": 0.5,  # Project budgets
                "quality control": 0.5,
            },
            ("engineering", "finance"): {  # Niche, e.g., quant roles, technical sales for eng products
                "quantitative analysis": 0.7, "problem solving": 0.7, "analytical skills": 0.8,
                "matlab": 0.6, "python": 0.5, "c++": 0.5,  # If used in eng role
                "modeling": 0.6, "simulation": 0.5,
                "data analysis": 0.6,
                "risk assessment": 0.5,
                "excel": 0.6,
            },
            ("engineering", "research_science"): {
                "research": 0.8, "data analysis": 0.8, "simulation": 0.9, "modeling": 0.9,
                "testing": 0.8, "experiment design": 0.7,
                "matlab": 0.8, "python": 0.7,
                "problem solving": 0.9, "analytical skills": 0.9,
                "technical documentation": 0.8,  # Papers, reports
                "specialized software": 0.7,  # FEA, CFD etc. might be used in research
                "laboratory skills": 0.6,  # Depending on eng field (e.g., ChemE, BioE)
            },
            # ==========================================
            # Healthcare -> Other Fields
            # ==========================================
            ("healthcare", "business"): {  # Admin, Pharma, Health Tech Business roles
                "project management": 0.7, "process improvement": 0.7, "compliance": 0.8,  # HIPAA
                "data analysis": 0.6,  # Operational data, patient outcomes
                "communication": 0.9,  # Patient/Stakeholder interaction
                "problem solving": 0.7, "attention to detail": 0.9, "documentation": 0.8,  # Meticulous records
                "teamwork": 0.9, "leadership": 0.6,  # Charge nurse -> Team lead
                "budget management": 0.5,  # Departmental budgets
                "customer service": 0.8,  # Patient care -> Customer focus
                "emr/ehr systems": 0.6,  # Understanding healthcare IT
                "scheduling": 0.7,
                "training": 0.6,  # Training staff/patients
            },
            ("healthcare", "technology"): {  # Health IT, Bioinformatics, Tech Support
                "emr/ehr systems": 0.8,  # Domain knowledge
                "hipaa compliance": 0.9,  # Crucial domain knowledge
                "problem solving": 0.8,  # Troubleshooting patient issues -> tech issues
                "attention to detail": 0.9,
                "documentation": 0.7,  # Processes, user issues
                "testing": 0.6,  # User perspective on software
                "data analysis": 0.6,  # Understanding health data needs
                "communication": 0.8,  # User support, training
                "project coordination": 0.6,  # Implementing systems
                "workflow analysis": 0.7,  # Understanding clinical workflows
            },
            ("healthcare", "education"): {  # Health education, Clinical instructor
                "teaching": 0.8, "training": 0.8, "mentoring": 0.7,
                "communication": 0.9, "presentation": 0.7,
                "curriculum development": 0.6,  # Health topics
                "assessment": 0.6,  # Assessing learners
                "subject matter expertise": 0.9,  # Specific health field
                "patience": 0.8, "empathy": 0.8,  # Soft skills
            },
            ("healthcare", "research_science"): {  # Clinical Research
                "clinical trials": 0.9, "patient recruitment": 0.8, "data collection": 0.8,
                "hipaa": 0.9, "regulatory compliance": 0.8,  # FDA, IRB
                "documentation": 0.9,  # Case report forms, protocols
                "medical terminology": 0.9,
                "data analysis": 0.6,  # Basic analysis of trial data
                "phlebotomy": 0.5,  # If research involves sample collection
                "patient monitoring": 0.7,
                "communication": 0.8,  # With patients, researchers
                "attention to detail": 0.9,
            },
            # ==========================================
            # Finance -> Other Fields
            # ==========================================
            ("finance", "technology"): {  # FinTech roles, Data Analysis
                "quantitative analysis": 0.8, "statistical modeling": 0.8,
                "python": 0.7, "sql": 0.7, "excel": 0.8,  # Tools overlap
                "data analysis": 0.9, "visualization": 0.7,
                "algorithms": 0.6,  # Quant finance -> general algorithms
                "risk management": 0.7,  # Financial risk -> Technical/Product risk
                "problem solving": 0.8, "analytical skills": 0.9,
                "database concepts": 0.6,
                "project management": 0.6,  # Financial projects
                "communication": 0.7,  # Explaining finance to techies
                "compliance": 0.6,  # Financial regs -> Tech regs (e.g., security)
            },
            ("finance", "business"): {  # General Business, Strategy, Operations
                "financial analysis": 0.9, "budgeting": 0.9, "forecasting": 0.8,
                "risk assessment": 0.8, "reporting": 0.8, "excel": 0.8,
                "data analysis": 0.8, "strategy": 0.7,  # Financial strategy -> Business strategy
                "valuation": 0.7, "compliance": 0.7,
                "communication": 0.7, "presentation": 0.7,
                "problem solving": 0.8, "analytical skills": 0.9,
                "project management": 0.6,
            },
            ("finance", "management"): {
                "leadership": 0.7,  # Managing finance teams
                "strategy": 0.7,  # Financial strategy
                "risk management": 0.8, "decision making": 0.8,  # Data-driven
                "budgeting": 0.9, "resource allocation": 0.7,
                "performance management": 0.6,  # Team performance
                "communication": 0.7, "presentation": 0.7,
                "problem solving": 0.8, "analytical skills": 0.9,
            },
            # ==========================================
            # Business -> Other Fields
            # ==========================================
            ("business", "technology"): {  # Product Mgmt, Project Mgmt, Tech Sales, BA
                "project management": 0.9, "agile methodologies": 0.7,
                "requirements gathering": 0.8, "stakeholder management": 0.8,
                "data analysis": 0.7, "market analysis": 0.6,  # -> Product analysis
                "strategy": 0.6,  # Business -> Product/Tech strategy
                "communication": 0.8,  # Liaison role
                "presentation": 0.7,
                "problem solving": 0.8,
                "process optimization": 0.6,  # Business process -> Software process
                "crm/erp knowledge": 0.6,  # Understanding systems landscape
                "user acceptance testing (uat)": 0.7,
                "leadership": 0.7,  # Business lead -> Team lead
            },
            ("business", "finance"): {
                "financial analysis": 0.7,  # If part of business role
                "budgeting": 0.7,  # Departmental/project budgets
                "forecasting": 0.6,
                "data analysis": 0.8,  # Business KPIs -> Financial KPIs
                "reporting": 0.7, "excel": 0.8,
                "risk assessment": 0.6,  # Business risk
                "strategy": 0.7,  # Business strategy informs financial needs
                "communication": 0.7, "presentation": 0.7,
                "problem solving": 0.8, "analytical skills": 0.8,
            },
            ("business", "marketing"): {  # Often closely related or overlapping
                "market analysis": 0.9, "competitive analysis": 0.9, "strategy": 0.8,
                "customer relationship management": 0.8, "sales": 0.7,  # Understanding drives marketing
                "presentation": 0.8, "communication": 0.9,
                "project management": 0.8,  # Campaign management
                "data analysis": 0.8,  # Market data, campaign results
                "budgeting": 0.7,  # Marketing budgets
                "product management": 0.7,  # Link between product and marketing
            },
            ("business", "management"): {  # Natural progression for many
                "leadership": 0.8, "strategy": 0.8, "project management": 0.8,
                "operations management": 0.8, "process improvement": 0.7,
                "team management": 0.7, "performance management": 0.6,
                "communication": 0.8, "presentation": 0.7, "negotiation": 0.7,
                "decision making": 0.8, "problem solving": 0.8,
                "budgeting": 0.7, "resource allocation": 0.7,
                "risk management": 0.7,
            },
            ("business", "education"): {  # Corporate training, Ed Business roles
                "training": 0.7, "presentation": 0.8, "communication": 0.8,
                "project management": 0.7,  # Developing training programs
                "curriculum development": 0.5,  # Business training materials
                "stakeholder management": 0.6,  # Working with learners, managers
                "needs analysis": 0.6,  # Training needs
            },
            # ==========================================
            # Education -> Other Fields
            # ==========================================
            ("education", "technology"): {  # Instructional Design, EdTech, Tech Training/Support
                "learning design": 0.8, "instructional design": 0.8,
                "curriculum development": 0.7,  # -> Documentation, training materials
                "educational technology": 0.9,  # LMS, authoring tools
                "assessment design": 0.6,  # -> QA, UAT design
                "presentation": 0.8, "communication": 0.9,  # Explaining complex topics
                "project coordination": 0.7, "project management": 0.6,
                "research": 0.6,  # User research needs
                "problem solving": 0.7,  # Helping learners -> helping users
                "content creation": 0.7,  # Manuals, guides
                "collaboration": 0.7,
            },
            ("education", "business"): {  # Corporate Training, HR (L&D), Consulting
                "training": 0.9, "presentation": 0.9, "communication": 0.9,
                "curriculum development": 0.7,  # Training programs
                "needs assessment": 0.7,  # Identifying training needs
                "project management": 0.7,  # Developing/rolling out programs
                "mentoring": 0.7, "coaching": 0.7,
                "assessment": 0.6,  # Evaluating training effectiveness
                "organization": 0.8, "planning": 0.8,
                "stakeholder management": 0.6,  # Working with managers/employees
                "leadership": 0.6,  # Classroom leadership -> team leadership
            },
            ("education", "management"): {  # School Admin, Training Manager, L&D Manager
                "leadership": 0.7,  # Leading teachers/students -> leading teams
                "planning": 0.8, "organization": 0.8,
                "curriculum development": 0.6,  # -> Program development
                "assessment": 0.6,  # -> Performance assessment
                "communication": 0.9, "presentation": 0.8,
                "mentoring": 0.7, "coaching": 0.7,
                "problem solving": 0.7, "conflict resolution": 0.7,  # Classroom -> Workplace
                "budget management": 0.5,  # School/department budgets
                "stakeholder management": 0.7,  # Parents, staff -> Employees, execs
            },
            # ==========================================
            # Creative -> Other Fields
            # ==========================================
            ("creative", "technology"): {  # UI/UX, Frontend Dev, Tech Marketing
                "user experience": 0.9, "user interface design": 0.9, "design": 0.8,
                "prototype development": 0.8,  # Figma, Sketch etc.
                "visual communication": 0.7, "storytelling": 0.6,  # Product narrative
                "user research": 0.8,
                "project management": 0.6, "collaboration": 0.8, "communication": 0.7,
                "problem solving": 0.7, "attention to detail": 0.8,
                "web development (frontend)": 0.6,  # If creative role involved web
                "content creation": 0.5,  # Documentation, UI text
                "branding": 0.5,  # Product branding
            },
            ("creative", "marketing"): {  # Core overlap
                "design": 0.9, "graphic design": 0.9, "visual communication": 0.9,
                "branding": 0.9, "content creation": 0.8, "copywriting": 0.8,
                "video production": 0.7, "photography": 0.7, "animation": 0.6,
                "storytelling": 0.8, "campaign development": 0.7,
                "user experience": 0.7,  # Website/landing page design
                "project management": 0.7, "collaboration": 0.8, "communication": 0.8,
                "social media content": 0.7,
                "adobe creative suite": 0.9,  # Tool overlap
            },
            ("creative", "business"): {  # Marketing, Product Design, Communications
                "communication": 0.8, "presentation": 0.8, "visual communication": 0.8,
                "design thinking": 0.7, "problem solving": 0.7,  # Creative solutions
                "project management": 0.7, "collaboration": 0.8,
                "branding": 0.7, "marketing concepts": 0.6,  # If learned
                "user experience": 0.6,  # Product design aspects
                "content creation": 0.6,  # Business comms, presentations
                "storytelling": 0.7,  # Pitching ideas
            },
            # ==========================================
            # Management -> Other Fields
            # ==========================================
            ("management", "technology"): {  # Tech Leadership, Program Management
                "project management": 0.9, "program management": 0.8,
                "agile": 0.8, "scrum": 0.8,  # Methodologies often transferable
                "leadership": 0.9, "team management": 0.9, "mentoring": 0.8,
                "strategy": 0.7,  # Business strategy -> Tech/Product strategy
                "process improvement": 0.7, "risk management": 0.7,
                "resource allocation": 0.8, "budget management": 0.7,
                "communication": 0.9, "stakeholder management": 0.8,
                "decision making": 0.8, "problem solving": 0.8,
                "performance management": 0.7,
            },
            ("management", "business"): {  # Higher-level Business roles, Consulting
                "leadership": 0.9, "strategy": 0.9, "operations management": 0.8,
                "project management": 0.8, "program management": 0.8,
                "financial acumen": 0.7,  # Understanding budgets, P&L if managed
                "risk management": 0.8, "decision making": 0.9, "problem solving": 0.8,
                "communication": 0.9, "negotiation": 0.8, "presentation": 0.8,
                "change management": 0.8, "process improvement": 0.7,
                "team leadership": 0.9, "stakeholder management": 0.8,
            },
            # ==========================================
            # Legal -> Other Fields (More Niche Transitions)
            # ==========================================
            ("legal", "business"): {  # Compliance, Risk, Contracts Mgmt, Consulting
                "contract negotiation": 0.9, "contract drafting": 0.8, "risk management": 0.8,
                "compliance": 0.9, "regulatory analysis": 0.8, "due diligence": 0.8,
                "analytical skills": 0.8, "problem solving": 0.7, "research": 0.7,
                "communication": 0.8,  # Clear writing, argumentation
                "negotiation": 0.9, "attention to detail": 0.9,
                "project management": 0.5,  # Managing cases/deals
                "stakeholder management": 0.6,  # Client management
            },
            ("legal", "finance"): {  # Compliance, Risk, Financial Regulation
                "compliance": 0.9, "risk management": 0.8, "regulatory analysis": 0.8,
                "due diligence": 0.8,  # M&A, investments
                "contract analysis": 0.7,  # Financial agreements
                "analytical skills": 0.8, "attention to detail": 0.9,
                "research": 0.7, "documentation": 0.8,
            },
            ("legal", "technology"): {  # Tech Compliance, Privacy Law, Legal Tech vendor roles
                "compliance": 0.8,  # GDPR, CCPA, Tech regulations
                "risk assessment": 0.7,  # Tech/Privacy risk
                "contract negotiation": 0.7,  # Tech contracts, SaaS agreements
                "data privacy": 0.9,  # Specialization
                "intellectual property": 0.7,  # Patents, trademarks (if specialized)
                "analytical skills": 0.7, "research": 0.7, "documentation": 0.7,
                "communication": 0.7,  # Explaining legal to tech teams
            },

            # ==========================================
            # Research/Science -> Other Fields
            # ==========================================
            ("research_science", "technology"): {
                "data analysis": 0.9, "python": 0.8, "r": 0.7,  # Common tools
                "statistical modeling": 0.8, "machine learning": 0.7,  # If used in research
                "simulation": 0.8, "modeling": 0.8,
                "problem solving": 0.9, "analytical skills": 0.9,
                "research": 0.9, "experiment design": 0.6,  # -> A/B testing etc.
                "documentation": 0.8,  # Papers -> Tech docs
                "visualization": 0.7,
                "linux": 0.6, "database management": 0.6,  # Research data
                "communication": 0.7,  # Presenting complex findings
                "subject matter expertise": 0.5,  # Depends heavily on the specific science field
            },
            ("research_science", "engineering"): {
                "problem solving": 0.9, "analytical skills": 0.9,
                "research": 0.9, "experiment design": 0.8, "testing": 0.8,
                "data analysis": 0.8, "simulation": 0.8, "modeling": 0.8,
                "matlab": 0.7, "python": 0.7,  # Tool overlap
                "technical documentation": 0.8,  # Reports, papers
                "laboratory skills": 0.6,  # If relevant (ChemE, BioE, Materials)
                "subject matter expertise": 0.7,  # Depends on field alignment
            },
            ("research_science", "healthcare"): {  # Medical Research, Pharma R&D, Bioinformatics
                "research": 0.9, "data analysis": 0.8, "statistical analysis": 0.8,
                "experiment design": 0.7, "laboratory skills": 0.7,  # If bio/chem related
                "subject matter expertise": 0.8,  # Biology, chemistry, medicine etc.
                "documentation": 0.8,  # Research protocols, papers
                "compliance": 0.6,  # Research ethics, potentially FDA regs
                "problem solving": 0.8, "analytical skills": 0.8,
                "bioinformatics tools": 0.8,  # If applicable
                "python": 0.7, "r": 0.7,  # Common in bioinformatics
            },

            # NOTE: "General/Admin" skills are broadly applicable. Instead of mapping *from* general,
            # relevant general skills are included *within* mappings from other fields where applicable
            # (e.g., communication, organization, problem solving). Mapping *to* General/Admin roles
            # might involve highlighting organizational, communication, and support skills from any field.
            # Example:
            ("any", "general_admin"): {  # Placeholder to illustrate the idea
                "communication": 0.9,
                "organization": 0.9,
                "time management": 0.8,
                "problem solving": 0.7,
                "attention to detail": 0.8,
                "documentation": 0.7,
                "planning": 0.7,
                "customer service": 0.6,  # If prior role was client/public facing
                "software proficiency": 0.6,  # MS Office, basic tools
            }

        }
        # Initialize with generic transferable skills for all industries
        for industry in INDUSTRY_CONFIGS:
            self.cross_industry_skills[industry] = {}
            for skill, score in generic_transferable.items():
                self.cross_industry_skills[industry][skill] = score

        # Add specific mappings
        for (source, target), mappings in specific_mappings.items():
            # Ensure source industry exists in the mapping
            if source not in self.cross_industry_skills:
                self.cross_industry_skills[source] = {}

            # Add skill mappings for source to target
            for skill, score in mappings.items():
                # Add to direct mapping
                self.cross_industry_skills[source][skill] = score

                # Ensure nested mapping exists for target
                if target not in self.cross_industry_skills[source]:
                    self.cross_industry_skills[source][target] = {}

                # Add to nested mapping
                self.cross_industry_skills[source][target][skill] = score

        # Define related domains
        self.related_domains = {
            # Technology and its sub-fields/connections
            "technology": [
                "engineering",  # Strong overlap (software eng, embedded)
                "data_science",  # Often considered a tech specialization
                "information_technology",  # IT operations, support
                "cybersecurity",  # Security specialization
                "cloud_computing",  # Cloud platforms (AWS, Azure, GCP)
                "devops",  # Development and Operations integration
                "web_development",  # Frontend/Backend
                "mobile_development",
                "ai_ml",  # Artificial Intelligence / Machine Learning
                "fintech",  # Technology in Finance
                "healthtech",  # Technology in Healthcare
                "edtech",  # Technology in Education
                "software_engineering",  # Core tech role
                "database_administration",
                "networking",
                "research_science",  # Tech research, computational science
                "business",  # Product Management, Tech Sales, BA roles
                "management"  # Tech management roles
            ],

            # Engineering connections (broad category + specific examples)
            "engineering": [
                "technology",  # Software, Embedded, Hardware eng.
                "manufacturing",  # Industrial, Mechanical, Chemical eng.
                "construction",  # Civil, Structural eng.
                "product_development",  # Design, R&D
                "research_science",  # Engineering research
                "management",  # Engineering management
                "aerospace", "automotive", "energy", "robotics",  # Industry applications
                "civil_engineering", "mechanical_engineering", "electrical_engineering",  # Sub-disciplines
                "chemical_engineering", "biomedical_engineering", "environmental_engineering",
                "industrial_engineering", "systems_engineering", "materials_science"
            ],
            # Specific Engineering Fields (can be added for more granularity)
            "civil_engineering": ["engineering", "construction", "environmental_engineering", "structural_engineering",
                                  "transportation", "geotechnical", "urban_planning"],
            "mechanical_engineering": ["engineering", "manufacturing", "automotive", "aerospace", "robotics", "hvac",
                                       "materials_science", "product_design"],
            "electrical_engineering": ["engineering", "technology", "electronics", "power_systems",
                                       "telecommunications", "control_systems", "embedded_systems",
                                       "computer_hardware"],
            # ... other specific engineering fields as needed ...

            # Healthcare connections
            "healthcare": [
                "biotechnology", "pharmaceutical", "medical_technology",  # Industry sectors
                "research_science",  # Clinical research, medical research
                "healthtech",  # Technology applied to healthcare
                "hospitality",  # Patient experience aspect
                "education",  # Medical education, patient education
                "management",  # Hospital administration, practice management
                "public_health",
                "mental_health",
                "nursing", "medicine", "dentistry", "therapy",  # Core professions
            ],

            # Business connections
            "business": [
                "finance", "marketing", "sales", "operations", "management",  # Core functions
                "human_resources", "supply_chain", "logistics",
                "consulting",  # Business advising
                "entrepreneurship",
                "project_management",
                "business_analytics",
                "technology",  # BA, Product Management, IT Management
                "legal",  # Corporate law, contracts
                "communications",
            ],

            # Finance connections
            "finance": [
                "accounting", "auditing",  # Core finance areas
                "investment_banking", "asset_management", "wealth_management",
                "financial_analysis", "quantitative_finance",  # Analytical roles
                "fintech",  # Intersection with technology
                "business_analytics",  # Data analysis in finance
                "risk_management", "compliance",
                "insurance", "real_estate",  # Related sectors
                "economics",
                "business",  # General business context
                "technology"  # Quant development, financial software
            ],

            # Data Science connections (often under Technology or Research)
            "data_science": [
                "technology",  # Core tools and platforms
                "artificial_intelligence", "machine_learning",  # Key techniques
                "business_analytics", "data_analysis",  # Related analytical fields
                "research_science",  # Data-driven research
                "statistics",
                "finance",  # Quantitative finance
                "healthcare",  # Bioinformatics, health informatics
                "marketing",  # Marketing analytics
                "engineering",  # Data from sensors, simulations
            ],

            # Marketing connections
            "marketing": [
                "business",  # Core business function
                "advertising", "public_relations", "communications",  # Related fields
                "digital_marketing", "social_media", "content_marketing", "seo",  # Digital channels
                "brand_management", "product_marketing",
                "market_research", "consumer_behavior",
                "sales",  # Closely related function
                "creative",  # Content creation, design
                "data_analysis",  # Marketing analytics
                "technology"  # MarTech tools
            ],

            # Creative connections
            "creative": [
                "design",  # Graphic, UI/UX, Product, Fashion etc.
                "media_production",  # Video, audio, animation
                "advertising", "marketing",  # Creative roles within these fields
                "digital_content", "writing", "editing",
                "fine_arts", "performing_arts",
                "architecture",  # Design-focused field
                "technology",  # UI/UX design, frontend dev, game design
                "journalism",
                "photography",
            ],

            # Education connections
            "education": [
                "training", "learning_development",  # Corporate context
                "instructional_design", "curriculum_development",
                "edtech",  # Technology in education
                "research_science",  # Educational research
                "administration",  # School/University admin
                "counseling", "library_science",
                "publishing",  # Educational materials
                "non_profit",  # Educational outreach
                "human_resources",  # L&D departments
            ],

            # Legal connections
            "legal": [
                "compliance", "regulatory",  # Key areas
                "intellectual_property", "patent_law", "trademark_law",
                "corporate_law", "contract_law",
                "litigation", "arbitration", "mediation",
                "government", "policy",
                "finance",  # Financial regulations, M&A law
                "business",  # Business law, contracts
                "technology",  # Cyber law, privacy law, tech contracts
                "human_resources",  # Employment law
                "paralegal_services",
            ],

            # Management connections (cross-functional)
            "management": [
                "business",  # General management
                "operations", "project_management", "program_management", "product_management",
                "strategy", "leadership",
                "human_resources",  # People management aspect
                "finance",  # Financial oversight
                "engineering",  # Engineering Management
                "technology",  # IT/Tech Management
                "healthcare",  # Healthcare Administration
                "non_profit_management",
                "supply_chain",
                "consulting",
            ],

            # Research/Science connections
            "research_science": [
                "technology",  # Computational science, R&D
                "engineering",  # R&D, specific eng fields (BioE, ChemE)
                "healthcare",  # Medical research, pharma R&D, biotech
                "data_science", "statistics", "mathematics",  # Foundational fields
                "education",  # Academic research, professorship
                "government",  # National labs, policy research
                "environment",  # Environmental science
                "physics", "chemistry", "biology",  # Core sciences
                "biotechnology", "pharmaceutical",  # Industry applications
            ],

            # Adding specific fields mentioned in INDUSTRY_SYNONYMS or SKILL_CATEGORIES as needed
            "ai_ml": ["data_science", "technology", "research_science", "robotics", "cognitive_science"],
            "cybersecurity": ["technology", "information_technology", "networking", "risk_management", "compliance",
                              "legal"],
            "devops": ["technology", "cloud_computing", "software_engineering", "information_technology",
                       "systems_engineering"],
            "fintech": ["finance", "technology", "banking", "data_science", "blockchain"],
            "healthtech": ["healthcare", "technology", "medical_devices", "biotechnology", "data_science"],
            "edtech": ["education", "technology", "instructional_design", "software_development"],
            "manufacturing": ["engineering", "operations", "supply_chain", "logistics", "quality_assurance",
                              "industrial_engineering", "mechanical_engineering"],
            "biotechnology": ["healthcare", "research_science", "pharmaceutical", "genetics", "molecular_biology",
                              "chemical_engineering"],
            "pharmaceutical": ["healthcare", "research_science", "biotechnology", "chemistry", "sales", "regulatory"],
            # ... add more specialized fields if the context requires deeper granularity
        }

    def detect_industry(self, text: str) -> Tuple[str, float]:
        """
        Detect the most likely industry for the given text.
        Returns a tuple of (industry_name, confidence_score)
        """
        text = text.lower()

        # Initialize industry scores for all known industries from INDUSTRY_CONFIGS
        industry_scores = {industry: 0.0 for industry in INDUSTRY_CONFIGS.keys()}

        # Add all industries from job title patterns to ensure they exist in the dictionary
        for industry in self.job_title_patterns.keys():
            if industry not in industry_scores:
                industry_scores[industry] = 0.0

        # Strategy 1: Job title pattern matching (highest weight)
        for industry, pattern in self.job_title_patterns.items():
            matches = pattern.findall(text)
            if matches:
                industry_scores[industry] += len(matches) * 2.0  # Higher weight for job title matches

        # Strategy 2: Industry-specific keyword counting
        for industry, config in INDUSTRY_CONFIGS.items():
            keywords = config.get('keywords', [])
            for keyword in keywords:
                if re.search(r'\b' + re.escape(keyword.lower()) + r'\b', text):
                    industry_scores[industry] += 0.5

        # Strategy 3: Experience pattern matching
        for industry, config in INDUSTRY_CONFIGS.items():
            patterns = config.get('experience_patterns', [])
            for pattern in patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                industry_scores[industry] += len(matches) * 0.3

        # Strategy 4: TF-IDF similarity
        try:
            # Convert industry profiles and input text to TF-IDF vectors
            profile_texts = list(self.industry_profiles.values())
            all_texts = profile_texts + [text]
            tfidf_matrix = self.vectorizer.fit_transform(all_texts)

            # Calculate similarities between input text and industry profiles
            text_vector = tfidf_matrix[-1]
            for i, industry in enumerate(self.industry_profiles.keys()):
                profile_vector = tfidf_matrix[i]
                similarity = cosine_similarity(text_vector, profile_vector)[0][0]
                industry_scores[industry] += similarity * 1.5  # Good weight for TF-IDF similarity
        except Exception as e:
            logger.warning(f"TF-IDF similarity calculation failed: {str(e)}")

        # Strategy 5: Embedding-based similarity if available
        if self.use_embeddings:
            try:
                text_embedding = self.sentence_transformer.encode(text)
                for industry, profile in self.industry_profiles.items():
                    profile_embedding = self.sentence_transformer.encode(profile)
                    similarity = self.util.pytorch_cos_sim(text_embedding, profile_embedding).item()
                    industry_scores[industry] += similarity * 2.0  # Highest weight for embedding similarity
            except Exception as e:
                logger.warning(f"Embedding similarity calculation failed: {str(e)}")

        # Get the best match and confidence score
        if not industry_scores:
            return "general", 0.0

        best_industry = max(industry_scores.items(), key=lambda x: x[1])
        industry_name = best_industry[0]
        # Normalize confidence to 0-1 range
        confidence = min(best_industry[1] / 10.0, 1.0)

        # Apply industry synonym mapping if needed
        normalized_industry = INDUSTRY_SYNONYMS.get(industry_name.lower(), industry_name)

        # If confidence is too low, fall back to "general"
        if confidence < 0.2:
            logger.info(f"Low confidence ({confidence:.2f}) for industry detection, using 'general'")
            return "general", confidence

        logger.info(f"Detected industry: {normalized_industry} with confidence {confidence:.2f}")
        return normalized_industry, confidence

    def get_industry_skill_categories(self, industry: str) -> Dict:
        """Get skill categories for a specific industry."""
        industry = INDUSTRY_SYNONYMS.get(industry.lower(), industry.lower())
        return SKILL_CATEGORIES.get(industry, SKILL_CATEGORIES.get("general", {}))

    def get_required_skills_for_industry(self, industry: str, job_description: str = None) -> Set[str]:
        """
        Get a set of skills that are typically required for a specific industry.
        If job_description is provided, it is used to refine the skill set.
        """
        industry = INDUSTRY_SYNONYMS.get(industry.lower(), industry.lower())

        # Start with industry-specific skills
        skill_categories = self.get_industry_skill_categories(industry)
        all_skills = set()

        # Extract skills from all categories
        for category, skills in skill_categories.items():
            if isinstance(skills, list):
                all_skills.update([s.lower() for s in skills])
            elif isinstance(skills, dict):
                for subcategory, subcategory_skills in skills.items():
                    all_skills.update([s.lower() for s in subcategory_skills])

        # If job description is provided, refine skills based on it
        if job_description:
            refined_skills = set()

            # Only keep skills that are mentioned in the job description
            for skill in all_skills:
                # Check for direct mentions
                if skill.lower() in job_description.lower():
                    refined_skills.add(skill)
                    continue

                # Check for partial matches (e.g., "Python" in "Python programming")
                skill_words = skill.lower().split()
                if any(word in job_description.lower() for word in skill_words if len(word) > 3):
                    refined_skills.add(skill)

            # If we have enough refined skills, use those
            if len(refined_skills) >= 5:
                return refined_skills

        return all_skills

    def get_transferable_skills(self, source_industry: str, target_industry: str) -> Dict[str, float]:
        """
        Get skills that are transferable from one industry to another with relevance scores.

        Args:
            source_industry: The original industry of the candidate
            target_industry: The industry of the job being applied for

        Returns:
            Dictionary mapping skill names to relevance scores (0-1)
        """
        source = source_industry.lower()
        target = target_industry.lower()

        # Same industry - all skills are directly transferable
        if source == target:
            skills = self.get_required_skills_for_industry(source)
            return {skill: 1.0 for skill in skills}

        transferable_skills = {}

        # Get generic transferable skills
        if source in self.cross_industry_skills:
            for skill, score in self.cross_industry_skills[source].items():
                if not isinstance(skill, dict):  # Make sure we're not getting a nested dict
                    transferable_skills[skill] = score

        # Get specific mappings for this industry pair
        if source in self.cross_industry_skills and target in self.cross_industry_skills[source]:
            if isinstance(self.cross_industry_skills[source][target], dict):
                specific_mappings = self.cross_industry_skills[source][target]
                for skill, score in specific_mappings.items():
                    transferable_skills[skill] = score

        # Add some soft skills that are always transferable
        soft_skills = {
            "communication": 0.9,
            "teamwork": 0.9,
            "problem solving": 0.9,
            "time management": 0.8,
            "adaptability": 0.8
        }
        transferable_skills.update(soft_skills)

        return transferable_skills


class IndustryAnalysisConfig:
    # A default configuration to use if no matching industry is found.
    DEFAULT_CONFIG = IndustryConfig(
        name="general",
        required_sections=["skills", "experience"],
        section_weights={"skills": 0.5, "experience": 0.5},
        keywords=["general"],
        skill_categories={"management": ["leadership"]},
        experience_patterns=[r"experience"],
        transferable_skills={}
    )

    def __init__(self):
        # Build configurations from the global INDUSTRY_CONFIGS constant.
        self.configs = {
            industry: IndustryConfig(
                name=industry,
                required_sections=config["required_sections"],
                section_weights=config["section_weights"],
                keywords=config["keywords"],
                skill_categories=config["skill_categories"],
                experience_patterns=config["experience_patterns"],
                transferable_skills={}  # Will be populated later
            )
            for industry, config in INDUSTRY_CONFIGS.items()
        }

        # Initialize the industry detector
        self.industry_detector = IndustryDetector()

        # Populate transferable skills for each industry
        self._populate_transferable_skills()

    def _populate_transferable_skills(self):
        """
        Populate transferable skills for all industry pairs.
        """
        for source in self.configs.keys():
            for target in self.configs.keys():
                if source != target:
                    transferable = self.industry_detector.get_transferable_skills(source, target)
                    if source in self.configs:
                        self.configs[source].transferable_skills[target] = transferable

    def _calculate_weights(self, job_description: str, required_sections: List[str]) -> Dict[str, float]:
        """
        Dynamically calculates section weights from the job description using TF-IDF.
        Returns a dictionary mapping each required section to a normalized weight.
        """
        vectorizer = TfidfVectorizer(stop_words='english')
        try:
            tfidf_matrix = vectorizer.fit_transform([job_description])
        except ValueError:
            return {section: 1.0 / len(required_sections) for section in required_sections}

        feature_names = vectorizer.get_feature_names_out()
        tfidf_scores = dict(zip(feature_names, tfidf_matrix.toarray()[0]))
        section_scores = defaultdict(float)
        for section in required_sections:
            # Gather section synonyms
            section_terms = [term for term, canon in SECTION_SYNONYMS.items() if canon == section]
            # For the skills section, add additional terms from the skill taxonomy (using "technology" as default)
            if section == "skills":
                skill_terms = []
                for cat in SKILL_CATEGORIES.get("technology", {}):
                    skill_terms.extend([term.lower() for term in SKILL_CATEGORIES["technology"].get(cat, [])])
                section_terms += skill_terms
            section_scores[section] = sum(tfidf_scores.get(term, 0) for term in section_terms)
        total = sum(section_scores.values()) or 1.0
        return {section: section_scores[section] / total for section in required_sections}

    def _enhance_patterns(self, base_patterns: List[str], industry: str) -> List[str]:
        """
        Enhances the provided regex patterns by appending additional keywords
        from the industry's skill categories and synonyms.
        """
        enhanced = list(base_patterns)
        industry_key = industry.lower()
        if industry_key in SKILL_CATEGORIES:
            skill_terms = []
            for cat in SKILL_CATEGORIES[industry_key].values():
                skill_terms.extend(cat)
            if skill_terms:
                enhanced.append(fr'\b({"|".join(map(re.escape, [s.lower() for s in skill_terms]))})\b')
        for syn, canon in INDUSTRY_SYNONYMS.items():
            if canon.lower() == industry_key:
                enhanced.append(fr'\b{re.escape(syn.lower())}\b')
        return enhanced

    def _identify_industry(self, job_description: str) -> str:
        """
        Use the IndustryDetector to identify the industry from a job description.
        """
        industry, confidence = self.industry_detector.detect_industry(job_description)
        logger.info(f"Industry detection: {industry} (confidence: {confidence:.2f})")
        return industry

    def _normalize_text(self, text: str) -> str:
        """
        Normalizes the text by converting to lowercase and replacing industry synonyms.
        """
        text = text.lower()
        for syn, canon in INDUSTRY_SYNONYMS.items():
            text = re.sub(rf'\b{re.escape(syn)}\b', canon, text)
        return text

    def get_config(self, job_description: str) -> IndustryConfig:
        """
        Returns an IndustryConfig instance based on the job description.
        Uses the IndustryDetector for more accurate industry identification.
        """
        industry = self._identify_industry(job_description)
        config_data = INDUSTRY_CONFIGS.get(industry, None)
        if not config_data:
            return self.DEFAULT_CONFIG

        section_weights = self._calculate_weights(job_description, config_data["required_sections"])
        return IndustryConfig(
            name=config_data['name'],
            keywords=config_data['keywords'] + self._get_skill_keywords(config_data),
            required_sections=config_data['required_sections'],
            section_weights=section_weights,
            skill_categories=config_data['skill_categories'],
            experience_patterns=self._enhance_patterns(config_data['experience_patterns'], config_data['name'].lower()),
            transferable_skills=self.configs.get(industry, self.DEFAULT_CONFIG).transferable_skills
        )

    def validate_section_weights(self, weights: Dict[str, float]) -> None:
        total = sum(weights.values())
        if not (0.99 <= total <= 1.01):
            raise ValueError(f"Section weights sum to {total:.2f}, must be 1.0")
        if any(weight < 0 or weight > 1 for weight in weights.values()):
            raise ValueError("All weights must be between 0 and 1")

    def get_custom_config(self,
                          name: str,
                          keywords: List[str],
                          required_sections: List[str],
                          section_weights: Dict[str, float],
                          skill_categories: List[str],
                          experience_patterns: List[str]) -> IndustryConfig:
        """
        Creates and returns a custom IndustryConfig instance after validating the provided parameters.
        """
        self.validate_required_sections(required_sections)
        self.validate_section_weights(section_weights)
        all_categories = set()
        for industry in SKILL_CATEGORIES.values():
            all_categories.update(industry.keys())
        invalid_cats = set(skill_categories) - all_categories
        if invalid_cats:
            raise ValueError(f"Invalid skill categories: {invalid_cats}")
        config_for_skills = {
            'name': name,
            'skill_categories': skill_categories
        }
        return IndustryConfig(
            name=name,
            keywords=keywords + self._get_skill_keywords(config_for_skills),
            required_sections=[SECTION_SYNONYMS.get(s.lower(), s) for s in required_sections],
            section_weights=section_weights,
            skill_categories=config_for_skills['skill_categories'],
            experience_patterns=self._enhance_patterns(experience_patterns, name.lower()),
            transferable_skills={}  # Empty for custom configs
        )

    def validate_required_sections(self, sections: List[str]) -> None:
        """
        Validates that every required section (after canonical mapping) is in the list of valid sections.
        """
        canonical_sections = [
            SECTION_SYNONYMS.get(s.lower().strip(), s.lower().strip())
            for s in sections
        ]
        valid_sections = set(SECTION_SYNONYMS.values())
        invalid = set(canonical_sections) - valid_sections
        if invalid:
            raise ValueError(f"Invalid sections: {invalid}. Valid options: {valid_sections}")

    def _get_skill_keywords(self, config: dict) -> list:
        """
        Extracts all lower-case skill keywords from the provided configuration.
        """
        industry_key = config['name'].lower()
        if industry_key not in SKILL_CATEGORIES:
            return []
        return [
            term.lower()
            for category in config['skill_categories']
            for term in SKILL_CATEGORIES[industry_key].get(category, [])
        ]

    def get_career_transition_map(self, source_industry: str, target_industry: str) -> Dict:
        """
        Get a mapping of how skills transfer between industries for career transitions.

        Args:
            source_industry: The candidate's current industry
            target_industry: The industry of the job they're applying for

        Returns:
            Dictionary with transferable skills, skill gaps, and recommended learning paths
        """
        source = source_industry.lower()
        target = target_industry.lower()

        # Get transferable skills
        transferable = self.industry_detector.get_transferable_skills(source, target)

        # Get required skills for target industry
        target_skills = self.industry_detector.get_required_skills_for_industry(target)
        transferable_skill_names = set(transferable.keys())

        # Identify skill gaps
        skill_gaps = target_skills - transferable_skill_names