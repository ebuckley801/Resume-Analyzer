# services/feedback_generator.py

"""
Resume Feedback Generator
Generates resume feedback using a combination of rule-based analysis and
LLM-based skill/action generation approach.
"""

import os
import re
import logging
import random
from typing import Dict, List, Set, Optional, Tuple
from collections import defaultdict
import openai
import spacy
import json
from spacy.matcher import PhraseMatcher
from transformers import pipeline
from nltk.corpus import wordnet
from .industry_config import IndustryAnalysisConfig, IndustryDetector, IndustryConfig
from .shared_utilities import (
    SKILL_CATEGORIES,
    INDUSTRY_CONFIGS,
    INDUSTRY_SYNONYMS,
    SEED_VERBS,
    WEAK_VERBS,
    GENERAL_FEEDBACK_RULES,
)

logger = logging.getLogger(__name__)


class ResumeFeedbackGenerator:
    """
    Generates resume feedback using a combination of rule-based analysis and,
    if available, a pre-trained or LLM-based approach for skills and achievements.
    
    Key features:
      - Optional model for zero-shot classification (Transformers).
      - Industry configurations to extract required skills and adjust weighting.
      - NLP analysis (using spaCy) of the resume text for style and keyword density.
      - Dynamic generation of recommendations (action verbs, achievements, etc.)
        using OpenAI's ChatCompletion, if an API key is available.
    """

    def __init__(self):
        # Validate required constants before initializing components
        self._validate_constants()

        # Initialize optional ML components
        try:
            self.skill_predictor = pipeline('zero-shot-classification', model='facebook/bart-large-mnli', revision="main", force_download=True)
        except Exception as e:
            logger.warning(
                "Transformer model for skill prediction not loaded. "
                "Proceeding without ML. Error: %s", str(e)
            )
            self.skill_predictor = None

        # Initialize core NLP components
        try:
            self.nlp = spacy.load("en_core_web_lg")
        except OSError:
            logger.error("spaCy model 'en_core_web_lg' not found. "
                         "Install with: python -m spacy download en_core_web_lg")
            raise
        except Exception as e:
            logger.error("Error loading spaCy model: %s", str(e))
            raise

        # Initialize industry configuration analyzer
        self.industry_config = IndustryAnalysisConfig()


    def _validate_constants(self) -> None:
        """
        Ensure required configuration constants are properly set.
        Removed reference to ACHIEVEMENT_TEMPLATES, as we now use a dynamic approach.
        """
        required_constants = [
            SKILL_CATEGORIES,
            SEED_VERBS,
            WEAK_VERBS,
            GENERAL_FEEDBACK_RULES
        ]
        # If any of them is empty or None, raise an error
        if any(not c for c in required_constants):
            logger.error("Missing required constants in configuration")
            raise ValueError("Incomplete constants configuration")
        
    def _normalize_position(self, position) -> dict:
        """
        Ensure that a position is represented as a dictionary with
        at least a 'title' key and a 'bullets' list.
        
        If the input is a string, it is assumed to be the title.
        If it is a dict, it is returned as is.
        Otherwise, the method converts the input to a string for the title.
        """
        if isinstance(position, dict):
            # Optionally, you can check if required keys are missing and fill them in.
            normalized = {
                "title": position.get("title", str(position)),
                "bullets": position.get("bullets", [])
            }
            return normalized
        elif isinstance(position, str):
            return {"title": position, "bullets": []}
        else:
            return {"title": str(position), "bullets": []}


    def _get_industry_context(self, job_description: str) -> Tuple[Optional[IndustryConfig], str]:
        """
        Determine industry context from job description using IndustryAnalysisConfig.
        
        Note: This method uses IndustryDetector indirectly through IndustryAnalysisConfig
        to maintain consistency with other industry detection methods and to reuse
        any configuration that happens during IndustryAnalysisConfig initialization.
        
        Args:
            job_description: The text to analyze for industry detection
            
        Returns:
            A tuple containing (industry_config, industry_name)
        """
        # Get an instance of IndustryAnalysisConfig and use its industry_detector
        industry_config = IndustryAnalysisConfig()
        industry_detector = industry_config.industry_detector
        
        # Detect industry with confidence score
        if job_description:
            detected_industry, confidence = industry_detector.detect_industry(job_description)
            if confidence > 0.3:  # Use detected industry if confidence is reasonable
                industry_name = detected_industry.lower()
                logger.info(f"Industry detection: {industry_name} (confidence: {confidence:.2f})")
            else:
                # Fall back to the original method if confidence is low
                cfg = self.industry_config.get_config(job_description)
                industry_name = cfg.name.lower() if cfg else 'general'
        else:
            industry_name = 'general'
        
        # Map through synonyms
        industry_name = INDUSTRY_SYNONYMS.get(industry_name, industry_name)
        
        # Get the config for this industry
        industry_cfg = None
        if industry_name in INDUSTRY_CONFIGS:
            industry_cfg = self.industry_config.get_config(job_description)
        
        return industry_cfg, industry_name

    def _get_industry_required_skills(self, industry: str) -> Set[str]:
        """
        Get normalized set of required skills for an industry.
        
        Note: This method uses IndustryDetector indirectly through IndustryAnalysisConfig
        to maintain consistency with industry skill retrieval across the codebase.
        
        Args:
            industry: The industry to get required skills for
            
        Returns:
            A set of required skills for the specified industry
        """
        # Get an instance of IndustryAnalysisConfig and use its industry_detector
        industry_config = IndustryAnalysisConfig()
        industry_detector = industry_config.industry_detector
        
        return industry_detector.get_required_skills_for_industry(industry)

    @staticmethod
    def get_wordnet_synonyms(base_verb: str, max_synonyms: int = 5) -> List[str]:
        """
        Returns a list of synonyms for a given verb from WordNet.
        """
        synonyms = set()
        for syn in wordnet.synsets(base_verb, pos=wordnet.VERB):
            for lemma in syn.lemmas():
                lemma_name = lemma.name().replace('_', ' ')
                if lemma_name.lower() != base_verb.lower():
                    synonyms.add(lemma_name)
        return list(synonyms)[:max_synonyms]

    @staticmethod
    def suggest_action_verbs_hybrid_wordnet(industry: str, max_seeds: int = 3, max_synonyms: int = 3) -> List[str]:
        """
        Merges a small curated set of seed verbs with synonyms from WordNet.
        """
        base_verbs = SEED_VERBS.get(industry.lower(), SEED_VERBS['general'])[:max_seeds]
        suggestions = set()

        for verb in base_verbs:
            suggestions.add(verb)
            # Expand with WordNet synonyms
            synonyms = ResumeFeedbackGenerator.get_wordnet_synonyms(verb, max_synonyms)
            suggestions.update(synonyms)

        return list(suggestions)

    @staticmethod
    def expand_verbs_with_llm(base_verbs: List[str],
                              job_description: str = "",
                              max_synonyms_per_verb: int = 3) -> List[str]:
        """
        Use OpenAI GPT-3.5 or GPT-4 to generate synonyms/related action verbs 
        for each verb in base_verbs, optionally tailored to a job description.
        """
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if not openai_api_key:
            # fallback if no key
            return base_verbs

        openai.api_key = openai_api_key
        new_verbs = set()

        for verb in base_verbs:
            prompt = f"""
            The job description is: {job_description}
            Suggest {max_synonyms_per_verb} synonyms or alternate action verbs 
            closely matching '{verb}' and suitable for a resume in this context.
            Only list the verbs, comma-separated.
            """

            try:
                response = openai.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=50,
                    temperature=0.7
                )
                synonyms_str = response.choices[0].message.content.strip()
                synonyms = [s.strip() for s in synonyms_str.split(',') if s.strip()]
                new_verbs.add(verb)
                new_verbs.update(synonyms)
            except Exception as e:
                logger.warning("LLM expansion failed for verb '%s': %s", verb, str(e))
                new_verbs.add(verb)

        return list(new_verbs)

    @staticmethod
    def suggest_action_verbs_hybrid_llm(industry: str,
                                        job_description: str,
                                        max_seeds: int = 3) -> List[str]:
        """
        Hybrid approach:
          1) Take a small curated set of domain-specific seed verbs
          2) Expand them using LLM synonyms
        """
        base_verbs = SEED_VERBS.get(industry.lower(), SEED_VERBS['general'])[:max_seeds]
        verbs_llm = ResumeFeedbackGenerator.expand_verbs_with_llm(base_verbs, job_description)
        return verbs_llm

    def _generate_dynamic_achievements(self, position: dict, analysis: dict, industry: str) -> List[str]:
        """
        Generate tailored achievements for a specific position using LLM.

        Considers:
        1. The specific position title and its context
        2. Industry best practices for achievement statements
        3. Resume skills and experience
        """
        role = position.get("title", "Unknown Role")
        bullets = position.get("bullets", [])
        duration = position.get("duration", {}).get("raw", "")

        # Get relevant skills that match this position
        skills = analysis.get('skills', {})
        skill_list = []
        for cat, items in skills.items():
            if cat != "errors":
                for item in items:
                    if isinstance(item, dict) and 'skill' in item:
                        skill_list.append(item['skill'])
                    elif isinstance(item, str):
                        skill_list.append(item)

        # Build a position-specific prompt
        position_prompt = f"""
    You are an expert resume writer helping a candidate with their {industry} resume. 
    Generate 2 highly effective bullet point achievements for this specific position:

    POSITION: {role}
    DURATION: {duration}
    EXISTING BULLETS: {bullets}
    CANDIDATE SKILLS: {', '.join(skill_list[:10])}

    Create 2 powerful, industry-specific achievement statements that:
    1. Start with strong action verbs (not "Helped", "Responsible for", etc.)
    2. Include specific metrics or quantifiable results (%, $, time savings, etc.)
    3. Highlight skills relevant to {industry} roles
    4. Follow the CAR format (Challenge-Action-Result)
    5. Are concise (15-20 words each)

    Format each as a complete bullet point, exactly as it would appear on a resume.
    """

        # Call LLM with this position-specific prompt
        return self._get_achievements_from_llm(position_prompt)

    def _add_verb_suggestions(self, feedback: Dict, industry: str, job_description: str = "") -> None:
        """
        Suggests industry-specific action verbs that are tailored to the
        specific job and industry context.
        """
        # First, get base industry verbs
        base_verbs = SEED_VERBS.get(industry.lower(), SEED_VERBS['general'])[:5]

        # Now tailor verb suggestions based on job description and industry
        prompt = f"""
    You are helping a job seeker improve their resume for a {industry} role.
    Based on this job description: "{job_description[:200]}..."

    Provide 5 powerful, specific action verbs that would be particularly impactful 
    in this {industry} resume. Only list the verbs, comma-separated.
    """

        # Call LLM to get tailored verb suggestions
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if not openai_api_key:
            verbs = base_verbs  # Fallback to base verbs
        else:
            try:
                openai.api_key = openai_api_key
                response = openai.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=30,
                    temperature=0.7
                )
                verbs_text = response.choices[0].message.content.strip()
                verbs = [v.strip() for v in verbs_text.split(',')]
                # Add some base verbs to ensure quality
                verbs = list(set(verbs + base_verbs[:2]))
            except Exception as e:
                logger.warning(f"LLM verb suggestion failed: {str(e)}")
                verbs = base_verbs  # Fallback

        if verbs:
            recommended = ', '.join(verbs[:5])
            feedback['recommendations'].append(
                f"Use stronger, domain-focused action verbs in your bullet points (e.g., {recommended})."
            )

    @staticmethod
    def find_weak_verbs_and_suggestions(doc, max_synonyms=3) -> dict:
        """
        Given a spaCy doc, find all verbs that appear in WEAK_VERBS 
        and suggest stronger replacements using WordNet or default synonyms.
        Return a dict: {weak_verb_in_text: [list_of_suggestions]}
        """
        suggestions_map = {}

        for token in doc:
            if token.pos_ == "VERB":
                lemma = token.lemma_.lower()
                if lemma in WEAK_VERBS:
                    # Try WordNet synonyms first
                    better_options = ResumeFeedbackGenerator.get_wordnet_synonyms(lemma, max_synonyms=max_synonyms)
                    if not better_options:
                        better_options = ["improved", "organized"]  # fallback
                    suggestions_map[token.text] = better_options
        return suggestions_map

    def _add_weak_verb_feedback(self, feedback: Dict, analysis: Dict) -> None:
        raw_text = analysis.get("raw_text", "")
        if not raw_text.strip():
            return

        doc = self.nlp(raw_text)
        suggestions_map = {}

        for token in doc:
            if token.pos_ == "VERB":
                lemma = token.lemma_.lower()
                text_lower = token.text.lower()
                if lemma in WEAK_VERBS or text_lower in WEAK_VERBS:
                    better_options = self.get_wordnet_synonyms(lemma, max_synonyms=3)
                    if not better_options:
                        better_options = ["enhanced", "improved", "led"]  # fallback
                    suggestions_map[token.text] = better_options

        if suggestions_map:
            lines = []
            for weak_verb, replacements in suggestions_map.items():
                lines.append(f"'{weak_verb}' -> try: {', '.join(replacements)}")

            feedback['improvements'].append(
                "Replace weak verbs with stronger ones:\n  " + "\n  ".join(lines)
            )

    def _add_education_feedback(self, feedback: Dict, analysis: Dict) -> None:
        """Provide feedback on the education section."""
        if not analysis.get("education"):
            feedback['improvements'].append("Include relevant education/certifications.")
        else:
            feedback['strengths'].append("Strong educational background noted.")

    def _add_job_match_feedback(self, feedback: Dict, job_match: Dict) -> None:
        """
        Add job matching analysis feedback (skills matched/missing, etc.).
        """
        skills_match = job_match.get('skills_match', {})
        missing_required = skills_match.get('required', {}).get('missing', [])
        matched_required = skills_match.get('required', {}).get('matched', [])
        if missing_required:
            feedback['improvements'].append(f"Missing requirements: {', '.join(missing_required[:3])}")
        if matched_required:
            feedback['strengths'].append(f"Matched requirements: {', '.join(matched_required[:3])}")

    def _finalize_feedback(self, feedback: Dict) -> Dict:
        """Deduplicate and limit feedback items."""
        for category in feedback:
            seen = set()
            filtered = []
            for item in feedback[category]:
                if item not in seen:
                    filtered.append(item)
                    seen.add(item)
            feedback[category] = filtered[:5]  # keep only up to 5 unique items
        return feedback

    def _detect_passive_voice(self, text: str) -> int:
        """
        Count passive voice constructions using spaCy.

        Args:
            text: The text to analyze for passive voice

        Returns:
            Integer count of passive voice instances
        """
        doc = self.nlp(text)
        passive_count = 0

        # Look for passive voice markers (auxpass dependency)
        for token in doc:
            if token.dep_ in ("auxpass", "nsubjpass"):
                passive_count += 1

        return passive_count

    def _add_style_feedback(self, feedback: Dict, analysis: Dict) -> None:
        """Provide writing style feedback (e.g., detect passive voice)."""
        raw_text = analysis.get("raw_text", "")
        if not raw_text.strip():
            return

        passive_count = self._detect_passive_voice(raw_text)
        threshold = GENERAL_FEEDBACK_RULES["passive_voice"]["threshold"]
        if passive_count > threshold:
            message = GENERAL_FEEDBACK_RULES["passive_voice"]["message"].format(count=passive_count)
            feedback["improvements"].append(message)

    def _validate_sections(self, resume_sections: dict, required_sections: List[str]) -> List[str]:
        """
        Return a list of missing required sections.

        Args:
            resume_sections: Dictionary of sections from the resume
            required_sections: List of sections required for the target industry

        Returns:
            List of section names that are missing from the resume
        """
        # Import SECTION_SYNONYMS from shared_utilities
        from .shared_utilities import SECTION_SYNONYMS

        # Convert section names to lowercase for case-insensitive comparison
        existing_sections = {section.lower() for section in resume_sections.keys()}

        # Check which required sections are missing
        missing = []
        for required in required_sections:
            required_lower = required.lower()
            if required_lower not in existing_sections:
                # Also check for synonyms (e.g., "work experience" vs. "experience")
                found_synonym = False
                for section in existing_sections:
                    if section in SECTION_SYNONYMS and SECTION_SYNONYMS[section] == required_lower:
                        found_synonym = True
                        break
                if not found_synonym:
                    missing.append(required)

        return missing

    def _analyze_skills(self, resume_text: str, industry: str) -> dict:
        """
        Rule-based skill analysis that returns structured data instead of feedback strings.

        Args:
            resume_text: Text from the resume to analyze
            industry: Target industry for comparison

        Returns:
            Dictionary with keyword density and keyword lists
        """
        try:
            doc = self.nlp(resume_text.lower())
            total_words = len(doc)
            if total_words == 0:
                return {
                    "keyword_density": 0.0,
                    "missing_keywords": [],
                    "found_keywords": []
                }

            # Get industry-specific required skills
            industry_terms = self._get_industry_required_skills(industry)

            # Find which industry terms exist in the resume
            tokens = [token.lemma_.strip() for token in doc if not token.is_punct and not token.is_stop]
            found_terms = set(tokens) & industry_terms

            # Check for multi-word terms using a matcher
            from spacy.matcher import PhraseMatcher
            matcher = PhraseMatcher(doc.vocab)
            patterns = [self.nlp.make_doc(phrase) for phrase in industry_terms if ' ' in phrase]
            if patterns:
                matcher.add("INDUSTRY_PHRASES", patterns)
                matches = matcher(doc)
                found_phrases = {doc[start:end].text for _, start, end in matches}
                found_terms.update(found_phrases)

            # Calculate keyword density
            keyword_count = len(found_terms)
            density = keyword_count / total_words if total_words > 0 else 0

            # Return structured results
            return {
                "keyword_density": density,
                "missing_keywords": sorted(industry_terms - found_terms)[:5],
                "found_keywords": sorted(found_terms)[:5]
            }
        except Exception as e:
            logger.error(f"Skill analysis error: {str(e)}")
            return {
                "keyword_density": 0.0,
                "missing_keywords": [],
                "found_keywords": []
            }

    def _add_general_feedback(self, feedback: Dict, analysis: Dict) -> None:
        """Add general resume quality feedback (e.g., word count, skill balance)."""
        general_rules = GENERAL_FEEDBACK_RULES
        stats = analysis.get('basic_stats', {})
        word_count = stats.get('word_count', 0)

        # Word count feedback
        if word_count > general_rules['word_count']['high']:
            feedback['improvements'].append(general_rules['word_count']['high_message'])
        elif word_count < general_rules['word_count']['low']:
            feedback['improvements'].append(general_rules['word_count']['low_message'])

        # Skill balance feedback
        skills = analysis.get('skills', {})
        tech_count = len(skills.get('technical', []))
        soft_count = len(skills.get('soft_skills', []))

        if tech_count == 0:
            feedback['improvements'].append("No technical skills listed.")
        elif tech_count > 0 and (soft_count / tech_count) < 0.6:
            feedback['improvements'].append(general_rules['skill_balance'])

    def _generate_dynamic_feedback_for_industry(
            self,
            analysis: dict,
            industry: str,
            job_description: str = "",
            # Add parameters for rule-based results
            keyword_density_score: Optional[float] = None,
            missing_keywords: Optional[List[str]] = None,
            passive_voice_count: Optional[int] = None,
            word_count: Optional[int] = None,
            skill_balance_issue: Optional[bool] = None,
            weak_verb_map: Optional[Dict[str, List[str]]] = None,
            key_missing_requirements: Optional[List[str]] = None,
            target_job_title: Optional[str] = None,
            experience_years: Optional[float] = None,
            missing_sections: Optional[List[str]] = None
    ) -> dict:
        """
        Use an LLM (e.g., OpenAI GPT) to generate dynamic feedback for the resume.
        The prompt explicitly requests three lists:
        1. Strengths
        2. Improvements (actionable advice for enhancing the resume)
        3. Recommendations (specific steps to take, not just rehashed achievements)
        """
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if not openai_api_key:
            return {
                "strengths": [f"No OpenAI key found. Static fallback for {industry}."],
                "improvements": [],
                "recommendations": []
            }

        openai.api_key = openai_api_key

        # Gather candidate info from the analysis.
        skills_found = analysis.get("skills", {})
        skill_snippets = []
        for _cat, skill_list in skills_found.items():
            for item in skill_list[:5]:
                if isinstance(item, dict):
                    skill_snippets.append(item.get('skill', ''))
                elif isinstance(item, str):
                    skill_snippets.append(item)
        skill_text = ", ".join(list(set(skill_snippets))) if skill_snippets else "None found"

        experience = analysis.get("experience", {})
        positions = experience.get("positions", [])
        roles_text = ", ".join(positions) if positions else "Not specified"

        prompt = f"""
    You are an expert resume consultant specializing in the {industry.capitalize()} domain.
    The candidate's resume details include:
    - Positions: {roles_text}
    - Key Skills: {skill_text}
    - Job Description Context (if available): {job_description[:300]}

    Please generate feedback in three distinct categories as valid JSON:
    1. "strengths": Bullet points that highlight the candidate's accomplishments and what they do well.
    2. "improvements": Bullet points that provide specific, actionable advice for improving the resume (e.g., clarifying responsibilities, adding missing certifications, improving bullet point structure).
    3. "recommendations": Bullet points that outline concrete next steps the candidate can take to enhance their resume (for example, reorganizing sections or using more impactful language). Avoid listing achievements here.

    The JSON output must have exactly these keys: "strengths", "improvements", and "recommendations", and each key must map to a list of concise bullet-point strings.
    For example:
    {{
    "strengths": ["Strong clinical expertise demonstrated in patient care", "..."],
    "improvements": ["Clarify responsibilities in the 'Experience' section", "..."],
    "recommendations": ["Revise bullet points to include quantifiable metrics", "..."]
    }}
        """

        try:
            response = openai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=0.7
            )
            content = response.choices[0].message.content.strip()
            try:
                feedback_json = json.loads(content)
            except json.JSONDecodeError:
                feedback_json = {
                    "strengths": [f"Unable to parse JSON from LLM: {content[:100]}..."],
                    "improvements": [],
                    "recommendations": []
                }
            for key in ["strengths", "improvements", "recommendations"]:
                if key not in feedback_json or not isinstance(feedback_json[key], list):
                    feedback_json[key] = []
            return feedback_json
        except Exception as e:
            return {
                "strengths": [],
                "improvements": [f"LLM call failed: {str(e)}"],
                "recommendations": []
            }

    def _build_feedback_prompt(self,
                               analysis: dict,
                               industry: str,
                               job_description: str,
                               rule_based_findings: dict,
                               target_job_title: str = None) -> str:
        """
        Build a detailed prompt for the LLM based on rule-based findings and analysis.

        Args:
            analysis: The complete resume analysis dictionary
            industry: Target industry for the job
            job_description: The job description text if available
            rule_based_findings: Dictionary of findings from rule-based analyses
            target_job_title: Specific job title if known

        Returns:
            Formatted prompt string for the LLM
        """
        # Extract candidate information
        skills_found = analysis.get("skills", {})
        skill_snippets = []
        for cat, skill_list in skills_found.items():
            if cat != "errors":
                for item in skill_list[:3]:  # Get top 3 from each category
                    if isinstance(item, dict):
                        skill_snippets.append(item.get('skill', ''))
                    elif isinstance(item, str):
                        skill_snippets.append(item)

        skill_text = ", ".join(list(set(skill_snippets))) if skill_snippets else "None found"

        # Extract experience information
        experience = analysis.get("experience", {})
        positions = experience.get("positions", [])
        total_years = experience.get("total_years", 0)
        roles_text = ", ".join(positions) if positions else "Not specified"

        # Format rule-based findings for the prompt
        findings_sections = []

        if "missing_sections" in rule_based_findings and rule_based_findings["missing_sections"]:
            missing = ", ".join(rule_based_findings["missing_sections"])
            findings_sections.append(f"- Resume is missing these important sections: {missing}")

        if "keyword_density" in rule_based_findings:
            density = rule_based_findings["keyword_density"]
            threshold = 0.07  # From GENERAL_FEEDBACK_RULES
            if density < threshold:
                missing_kw = ", ".join(rule_based_findings.get("missing_keywords", []))
                findings_sections.append(
                    f"- Industry keyword density is low ({density:.1%} < {threshold:.0%}). "
                    f"Missing relevant keywords: {missing_kw}"
                )

        if "passive_voice" in rule_based_findings and rule_based_findings["passive_voice"] > 1:
            findings_sections.append(
                f"- Found {rule_based_findings['passive_voice']} instances of passive voice. "
                f"Active voice is more impactful for resumes."
            )

        if "word_count" in rule_based_findings:
            count = rule_based_findings["word_count"]
            if count > 800:
                findings_sections.append(f"- Resume is too long ({count} words, recommended: 300-800 words)")
            elif count < 300:
                findings_sections.append(f"- Resume is too short ({count} words, recommended: 300-800 words)")

        if "weak_verbs" in rule_based_findings and rule_based_findings["weak_verbs"]:
            verb_examples = []
            for weak, suggestions in list(rule_based_findings["weak_verbs"].items())[:3]:
                verb_examples.append(f"'{weak}' → {', '.join(suggestions[:2])}")

            findings_sections.append(
                f"- Several weak verbs identified that could be strengthened. Examples: {'; '.join(verb_examples)}"
            )

        if "missing_requirements" in rule_based_findings and rule_based_findings["missing_requirements"]:
            missing_req = ", ".join(rule_based_findings["missing_requirements"][:5])
            findings_sections.append(
                f"- Key missing skills/requirements for {target_job_title or industry} roles: {missing_req}"
            )

        formatted_findings = "\n".join(findings_sections) if findings_sections else "No specific issues found."

        # Construct the final prompt
        prompt = f"""
    You are an expert career coach specialized in {industry.capitalize()} careers analyzing a resume for a job seeker targeting a {target_job_title or industry} role.

    CANDIDATE PROFILE:
    - Experience: {total_years} years total experience
    - Positions held: {roles_text}
    - Key skills: {skill_text}

    RULE-BASED ANALYSIS FINDINGS:
    {formatted_findings}

    JOB DESCRIPTION CONTEXT:
    {job_description[:300] if job_description else "Not provided"}

    Based on the candidate's profile and the rule-based findings above, generate feedback as valid JSON with these keys:

    1. "improvements" (5 items): Provide specific, actionable advice to enhance the resume. Address the rule-based findings directly and explain WHY these changes matter specifically for {industry} roles.

    2. "recommendations" (5 items): Suggest concrete bullet points the candidate could add to their resume with specific achievements formatted as they would appear on the resume. For example, for an engineering role, include measurable achievements like "Reduced manufacturing costs by 15% through implementation of automated testing procedures."

    3. "strengths" (3-4 items): Highlight the candidate's strongest qualifications that are relevant to {industry} roles.

    Make all feedback industry-specific, actionable, and relevant to the target role. Each item should be a complete sentence and be specific rather than generic.
    """
        return prompt

    def _call_llm_with_prompt(self, prompt: str) -> dict:
        """
        Call OpenAI LLM with the prompt and parse the response.

        Args:
            prompt: The fully formatted prompt to send to the LLM

        Returns:
            Dictionary with feedback categorized into strengths, improvements, and recommendations
        """
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if not openai_api_key:
            return {
                "strengths": ["Unable to generate detailed feedback (no API key)"],
                "improvements": [],
                "recommendations": []
            }

        try:
            openai.api_key = openai_api_key
            response = openai.chat.completions.create(
                model="gpt-4o-mini",  # You can adjust based on your needs/availability
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.7
            )
            content = response.choices[0].message.content.strip()

            try:
                # Parse JSON response
                feedback_json = json.loads(content)
                # Ensure required keys are present
                for key in ["strengths", "improvements", "recommendations"]:
                    if key not in feedback_json or not isinstance(feedback_json[key], list):
                        feedback_json[key] = []
                return feedback_json
            except json.JSONDecodeError:
                # If JSON parsing fails, try to extract lists using regex
                strengths = re.findall(r'"strengths":\s*\[(.*?)\]', content, re.DOTALL)
                improvements = re.findall(r'"improvements":\s*\[(.*?)\]', content, re.DOTALL)
                recommendations = re.findall(r'"recommendations":\s*\[(.*?)\]', content, re.DOTALL)

                # Process regex matches
                result = {
                    "strengths": [],
                    "improvements": [],
                    "recommendations": []
                }

                # Parse lists from regex matches if available
                if strengths:
                    result["strengths"] = [s.strip(' "\'') for s in re.findall(r'"(.*?)"', strengths[0])]
                if improvements:
                    result["improvements"] = [s.strip(' "\'') for s in re.findall(r'"(.*?)"', improvements[0])]
                if recommendations:
                    result["recommendations"] = [s.strip(' "\'') for s in re.findall(r'"(.*?)"', recommendations[0])]

                return result

        except Exception as e:
            return {
                "strengths": [],
                "improvements": [f"LLM generation failed: {str(e)}"],
                "recommendations": []
            }

    def _add_achievement_feedback(self, feedback: Dict, analysis: Dict, industry: str) -> None:
        """
        Add achievement-based recommendations using dynamic LLM generation.
        """
        positions = analysis.get('experience', {}).get('positions')
        if not positions:
            logger.info("No experience data for achievement feedback.")
            return

        for pos in positions:
            try:
                position = self._normalize_position(pos)
                suggestions = self._generate_dynamic_achievements(position, analysis, industry)
                # Add only up to 2 suggestions to keep it concise
                feedback['recommendations'].extend(suggestions[:2])
            except Exception as e:
                pos_title = self._normalize_position(pos).get('title', 'Unknown')
                logger.warning("Dynamic achievement generation failed for position '%s': %s", pos_title, str(e))

    def _get_achievements_from_llm(self, prompt: str) -> List[str]:
        """
        Get achievement suggestions from LLM based on a specific prompt.
        """
        openai_api_key = os.getenv("OPENAI_API_KEY")
        if not openai_api_key:
            return ["Example achievement bullet point (API key missing)"]

        try:
            openai.api_key = openai_api_key
            response = openai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=200,
                temperature=0.7
            )
            text_output = response.choices[0].message.content.strip()
            # Split on newlines, ignoring blank lines
            lines = [line.strip() for line in text_output.split('\n') if line.strip()]
            return lines
        except Exception as e:
            logger.warning("LLM achievement generation failed: %s", str(e))
            # Fallback
            return ["Example achievement bullet point (LLM call failed)"]

    def generate_feedback(self, analysis_results: Dict, job_description: str = None) -> Dict:
        """
        Generate comprehensive resume feedback using a hybrid approach:
        1) Run rule-based checks and collect structured findings
        2) Use LLM to synthesize findings into coherent, contextual feedback
        3) Combine and format the final feedback
        """
        # Initialize findings dictionary to hold rule-based analysis results
        rule_based_findings = {}

        # Initialize the feedback structure for return
        feedback = {
            'strengths': [],
            'improvements': [],
            'recommendations': []
        }

        # Get raw text and determine industry context
        raw_text = analysis_results.get("raw_text", "")
        industry_cfg, industry_name = self._get_industry_context(job_description or "")

        # Determine target job title (if possible)
        target_job_title = None
        if job_description:
            # Extract job title from job description (simplified example)
            first_line = job_description.split('\n')[0] if job_description else ""
            if len(first_line.split()) <= 10:  # Assume first short line might be the title
                target_job_title = first_line

        # Run rule-based analyses and collect structured results

        # 1. Check for missing sections
        if industry_cfg and hasattr(industry_cfg, 'required_sections'):
            required_sections = industry_cfg.required_sections
            missing_sections = self._validate_sections(analysis_results.get('sections', {}), required_sections)
            if missing_sections:
                rule_based_findings["missing_sections"] = missing_sections

        # 2. Analyze skills and keyword density
        skills_analysis = self._analyze_skills(raw_text, industry_name)
        rule_based_findings["keyword_density"] = skills_analysis["keyword_density"]
        rule_based_findings["missing_keywords"] = skills_analysis["missing_keywords"]
        rule_based_findings["found_keywords"] = skills_analysis["found_keywords"]

        # 3. Check for passive voice
        passive_count = self._detect_passive_voice(raw_text)
        rule_based_findings["passive_voice"] = passive_count

        # 4. Get basic stats
        stats = analysis_results.get('basic_stats', {})
        rule_based_findings["word_count"] = stats.get('word_count', 0)

        # 5. Check education
        has_education = bool(analysis_results.get("education"))
        rule_based_findings["has_education"] = has_education

        # 6. Get missing job requirements
        if 'job_match' in analysis_results:
            job_match = analysis_results['job_match']
            missing_req = job_match.get('skills_match', {}).get('required', {}).get('missing', [])
            rule_based_findings["missing_requirements"] = missing_req

        # 7. Analyze weak verbs
        weak_verbs = self.find_weak_verbs_and_suggestions(self.nlp(raw_text))
        rule_based_findings["weak_verbs"] = weak_verbs

        # 8. Experience analysis
        exp_data = analysis_results.get('experience', {})
        rule_based_findings["total_years"] = exp_data.get('total_years', 0)

        # Now use the LLM to generate feedback based on rule-based findings
        # Use the new comprehensive prompt builder
        prompt = self._build_feedback_prompt(
            analysis_results,
            industry_name,
            job_description or "",
            rule_based_findings,
            target_job_title
        )

        # Call the LLM with the enhanced prompt
        llm_feedback = self._call_llm_with_prompt(prompt)

        # Populate the feedback structure with LLM output
        feedback['strengths'] = llm_feedback.get("strengths", [])
        feedback['improvements'] = llm_feedback.get("improvements", [])
        feedback['recommendations'] = llm_feedback.get("recommendations", [])

        # Add achievement suggestions for each job/position if needed
        # Keep your existing achievement generation logic
        self._add_achievement_feedback(feedback, analysis_results, industry_name)

        # Add strong action verb suggestions
        self._add_verb_suggestions(feedback, industry_name, job_description)

        # If no feedback was generated at all, insert a fallback note
        if not (feedback["strengths"] or feedback["improvements"] or feedback["recommendations"]):
            feedback["improvements"].append(
                "No significant feedback generated – check resume content."
            )

        # Deduplicate and limit items in each feedback category, then return
        return self._finalize_feedback(feedback)

