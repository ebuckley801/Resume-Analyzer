# resume_matcher_services/__init__.py

"""
Resume Matcher Services - Core business logic for Resume Analysis and Job Matching
"""

# Import main services to make them available at the package level
from .security import hash_password, verify_password, validate_password_complexity, get_password_rules
from .file_parser import extract_text
from .skills_extractor import SkillsExtractor
from .job_analyzer import JobDescriptionAnalyzer
from .resume_analyzer import ResumeAnalyzer, analyzer  # Import both the class and the instance
from .section_extractor import SectionExtractor
from .education_parser import EducationParser
from .experience_parser import ExperienceParser
from .feedback_generator import ResumeFeedbackGenerator
from .text_analysis import TextAnalyzer
from .industry_config import IndustryDetector, IndustryAnalysisConfig, IndustryConfig

# Create wrapper functions for common operations to maintain backward compatibility
def extract_skills(text, industry="technology"):
    """Wrapper function for SkillsExtractor's extract_skills method."""
    extractor = SkillsExtractor()
    return extractor.extract_skills(text, industry)

def analyze_job_description(job_description):
    """Wrapper function for JobDescriptionAnalyzer's analyze_job_description method."""
    job_analyzer = JobDescriptionAnalyzer()
    return job_analyzer.analyze_job_description(job_description)

def calculate_text_similarity(text1, text2):
    """Wrapper function for TextAnalyzer's analyze_similarity method."""
    analyzer = TextAnalyzer()
    return analyzer.analyze_similarity(text1, text2)

__version__ = '0.1.0'