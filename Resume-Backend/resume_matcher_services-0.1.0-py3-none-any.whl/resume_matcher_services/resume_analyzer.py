# services/resume_analyzer.py
import re
import spacy
import logging
from datetime import datetime
from dateutil.parser import parse as parse_date
from typing import Optional, Dict, List, Set, Tuple

# Import specialized modules for section, education, experience, skills, and job analysis.
from .section_extractor import SectionExtractor
from .education_parser import EducationParser
from .experience_parser import ExperienceParser
from .skills_extractor import SkillsExtractor
from .job_analyzer import JobDescriptionAnalyzer
from .industry_config import IndustryAnalysisConfig, IndustryDetector
from .shared_utilities import load_config, INDUSTRY_CONFIGS, HEADER_KEYWORDS, SECTION_SYNONYMS, SKILL_CATEGORIES, GENERAL_FEEDBACK_RULES

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class ResumeAnalyzer:
    def __init__(self):
        # Load the spaCy transformer model with a configuration that limits batch size.
        self.nlp = spacy.load("en_core_web_trf", config={"nlp": {"batch_size": 1}})
        self.nlp.max_length = 20000  # Adjust if necessary

        # Load configuration settings.
        self.config = load_config()

        # Initialize specialized modules.
        self.section_extractor = SectionExtractor(self.nlp, self.config)
        self.education_parser = EducationParser(self.nlp)
        self.experience_parser = ExperienceParser(self.nlp, self.config)
        self.job_analyzer = JobDescriptionAnalyzer()
        # For skills extraction, load a transformer-based model (excluding lemmatizer and NER for speed).
        self.skills_extractor = SkillsExtractor(spacy.load("en_core_web_trf", exclude=["lemmatizer", "ner"]),
                                                self.config)

        # Initialize industry detector for better cross-industry matching
        self.industry_detector = IndustryDetector()

    def robust_insert_section_markers(self, text: str) -> str:
        """
        Scans the text and inserts explicit section markers ("## ... ##") for lines that are likely headers.
        If the text is flat (has very few newlines), it first inserts newlines before any occurrence of a known
        header keyword (from HEADER_KEYWORDS).
        """
        # If the text is flat (e.g., extracted from a PDF), insert newlines before known section keywords.
        if text.count('\n') < 5:
            for header in HEADER_KEYWORDS:
                # This regex looks for the header keyword not already preceded by a newline or marker.
                pattern = re.compile(r'(?<!\n)(?<!## )\b(' + re.escape(header) + r')\b', re.IGNORECASE)
                # Insert a newline and markers before the header keyword.
                text = pattern.sub(r'\n## \1 ##', text)

        # Now split the text into lines and process each line.
        lines = text.splitlines()
        new_lines = []
        for line in lines:
            stripped = line.strip()
            # Preserve empty lines.
            if not stripped:
                new_lines.append(line)
                continue
            # If already marked as a header, preserve.
            if stripped.startswith("##") and stripped.endswith("##"):
                new_lines.append(line)
                continue
            # If the line is short (<=10 words), check if it contains any known header keyword.
            if len(stripped.split()) <= 10:
                lower_line = stripped.lower()
                for header in HEADER_KEYWORDS:
                    if header in lower_line:
                        new_lines.append(f"## {stripped} ##")
                        break
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)
        return "\n".join(new_lines)

    def _preprocess_headers(self, text: str) -> str:
        """
        Standardizes keywords (e.g. "present") and ensures that every "##" marker is on its own line.
        If no markers are found (common with PDF extraction), insert them using robust_insert_section_markers.
        """
        text = re.sub(r'\b(present|current)\b', "Present", text, flags=re.IGNORECASE)
        # Force a newline before every "##" so headers are isolated.
        text = re.sub(r'\s*##\s*', r'\n## ', text)
        # If no markers exist, insert them robustly.
        if "##" not in text:
            text = self.robust_insert_section_markers(text)
        return text

    def analyze_resume(self, text: str, job_description: str = None, sections: dict = None) -> dict:
        """
        Analyzes the resume by:
        1. Preprocessing header text (ensuring keywords are standardized and "##" markers are on new lines).
        2. Handling pre-extracted sections or splitting the resume into sections if needed.
        3. Identifying the Education and Experience sections by keyword.
        4. Computing basic text statistics.
        5. Extracting skills, education, experience, and contact info.
        6. Optionally performing job matching analysis.

        Args:
            text: The full text of the resume
            job_description: Optional job description to match against
            sections: Optional pre-extracted sections dictionary with section names as keys

        Returns:
            Dictionary containing comprehensive resume analysis
        """
        # Preprocess the text to standardize and isolate header markers.
        text = self._preprocess_headers(text)

        # Validate and normalize sections if provided
        if sections is not None:
            # Use section_extractor's validate_sections method
            is_valid, normalized_sections, warning_msg = self.section_extractor.validate_sections(sections)

            if not is_valid:
                logger.warning(f"Invalid sections: {warning_msg}. Falling back to extraction.")
                sections = None
            else:
                sections = normalized_sections
                if warning_msg:
                    logger.warning(warning_msg)

            # If somehow we ended up with empty sections dict, set to None to trigger extraction
            if sections is not None and not sections:
                logger.warning("Provided sections were empty. Falling back to extraction.")
                sections = None

        # Use provided sections if available; otherwise, extract from the raw text.
        if sections is None:
            if "##" in text:
                sections = self._split_sections_by_markers(text)
            else:
                sections = self.section_extractor.detect_sections(text)
            if not sections:
                # If no sections were detected, at least keep the raw text
                sections = {"raw": text}

        # Add the raw text to sections if not already present
        if "raw" not in sections:
            sections["raw"] = text

        # Identify the Education section by scanning for headers that contain "educat"
        education_section_txt = ""
        for key, value in sections.items():
            if "educat" in key.lower():
                education_section_txt = value.strip()
                break
        if not education_section_txt:
            education_section_txt = text

        # Identify the Experience section by scanning for headers containing "experien" or "work"
        experience_section_txt = ""
        for key, value in sections.items():
            if any(term in key.lower() for term in ["experien", "work", "professional"]):
                experience_section_txt = value.strip()
                break
        if not experience_section_txt:
            experience_section_txt = text

        # Look for skills section
        skills_section_txt = ""
        for key, value in sections.items():
            if "skill" in key.lower():
                skills_section_txt = value.strip()
                break

        # Compute basic statistics
        basic_stats = self._get_basic_stats(sections)

        # Initialize the analysis result dictionary
        analysis = {
            "sections": sections,
            "raw_text": text,
            "basic_stats": basic_stats,
        }

        # Determine industry configuration (and run job analysis if provided)
        job_analysis = None
        target_industry = "general"

        if job_description:
            job_analysis = self.job_analyzer.analyze_job_description(job_description)
            target_industry = job_analysis.get("industry_type", "general").lower()
            industry_cfg = INDUSTRY_CONFIGS.get(target_industry, INDUSTRY_CONFIGS["general"])
        else:
            industry_cfg = INDUSTRY_CONFIGS["general"]

        # Detect the resume's primary industry for better cross-domain matching
        resume_industry, _ = self.industry_detector.detect_industry(text)
        analysis["resume_industry"] = resume_industry

        # --- Skills Extraction ---
        # Pass both resume industry and target job industry for better cross-domain skills extraction
        if skills_section_txt:
            skills = self.skills_extractor.extract_skills(skills_section_txt,
                                                          industry=resume_industry,
                                                          target_job=job_description)
        else:
            skills = self.skills_extractor.extract_skills(text,
                                                          industry=resume_industry,
                                                          target_job=job_description)

        # Filter and enhance skills extraction
        skills = self._enhance_skills_extraction(skills, resume_industry, target_industry)
        analysis["skills"] = skills

        # --- Experience Extraction ---
        experience_data = self.experience_parser.parse(experience_section_txt)
        if not experience_data.get("positions"):
            experience_data["positions"] = self._extract_positions_from_experience(experience_section_txt)
        if not experience_data.get("total_years") or experience_data.get("total_years") == 0.0:
            # Use our fallback method to sum durations from date ranges
            experience_data["total_years"] = self._calculate_total_experience_years(experience_section_txt)

        # Add leadership roles and normalize positions
        experience_data = self._enhance_experience_data(experience_data, text)
        analysis["experience"] = experience_data

        # --- Education Extraction ---
        education_data = self._extract_education_fixed(education_section_txt)
        analysis["education"] = education_data
        analysis["education_analysis"] = education_data

        # --- Contact Information Extraction ---
        contact_info = self._extract_contact_info(text)
        analysis["contact_info"] = contact_info

        # --- Job Matching Analysis (if applicable) ---
        if job_description and job_analysis:
            analysis["job_match"] = self._perform_job_matching(
                resume_text=text,
                resume_skills=skills,
                resume_experience=experience_data,
                resume_industry=resume_industry,
                job_description=job_description,
                job_analysis=job_analysis,
                target_industry=target_industry,
                industry_cfg=industry_cfg
            )

        return analysis

    def _split_sections_by_markers(self, text: str) -> Dict[str, str]:
        """
        Splits the text into sections using explicit "##" markers.
        Assumes that each header marker is at the start of a line.
        """
        pattern = re.compile(r'\n##\s*(.*?)\s*##\s*')
        parts = pattern.split(text)
        sections = {}
        if len(parts) > 1:
            if parts[0].strip():
                sections["raw"] = parts[0].strip()
            # Process pairs: header followed by content.
            for i in range(1, len(parts) - 1, 2):
                header = parts[i].strip().lower()
                content = parts[i + 1].strip()
                sections[header] = content
        else:
            sections["raw"] = text
        return sections

    def _auto_detect_sections(self, text: str) -> Dict[str, str]:
        """
        As a fallback, automatically detect section headers by scanning for short, all-uppercase lines.
        """
        sections = {}
        current_header = "raw"
        current_lines = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and stripped == stripped.upper() and len(stripped.split()) < 10:
                if current_lines:
                    sections[current_header] = "\n".join(current_lines).strip()
                current_header = stripped.lower()
                current_lines = []
            else:
                current_lines.append(line)
        if current_lines:
            sections[current_header] = "\n".join(current_lines).strip()
        return sections

    def _get_basic_stats(self, text) -> dict:
        """
        Computes basic statistics (word count, average sentence length, section count)
        from the provided resume text. If a dictionary of sections is provided, all values
        are concatenated into a single text for analysis.
        """
        # If text is a dict (i.e., a sections dictionary), join its values.
        if isinstance(text, dict):
            combined_text = "\n".join(text.values())
        else:
            combined_text = text

        words = combined_text.split()
        word_count = len(words)
        # Split on period, but only consider non-empty parts.
        sentences = [s for s in combined_text.split('.') if s.strip()]
        avg_sentence_length = word_count / len(sentences) if sentences else 0
        # Count sections by splitting on newline; this is just one measure.
        section_count = len(combined_text.split('\n'))
        return {
            'word_count': word_count,
            'avg_sentence_length': round(avg_sentence_length, 2),
            'section_count': section_count
        }

    def _extract_education_fixed(self, text: str) -> List[dict]:
        records = self.education_parser.parse(text)
        fixed = []
        for rec in records:
            school = rec.get("school", "").strip()
            if len(school) < 4:
                candidates = [line for line in text.splitlines()
                              if any(
                        kw in line.lower() for kw in ["university", "college", "institute", "academy", "school"])]
                if candidates:
                    rec["school"] = candidates[0].strip()
            fixed.append(rec)
        return fixed

    def _extract_positions_from_experience(self, text: str) -> list:
        """
        Enhanced extraction of positions from the experience section.
        Tries multiple regex patterns for different formats.
        """
        positions = []

        # Different formats to try
        patterns = [
            # Pattern A: "Company, Position, Location, Date..."
            r'^(?P<company>.+?),\s*(?P<position>.+?),\s*(?P<location>.+?)\s+(?P<date_range>.+)$',
            # Pattern B: "Position, Company, Location, Date..."
            r'^(?P<position>.+?),\s*(?P<company>.+?),\s*(?P<location>.+?)\s+(?P<date_range>.+)$',
            # Pattern C: "Position at Company (Date...)"
            r'^(?P<position>.+?)\s+at\s+(?P<company>.+?)\s*\((?P<date_range>.+)\)',
            # Pattern D: "Position - Company - Date..."
            r'^(?P<position>.+?)\s+-\s+(?P<company>.+?)\s+-\s+(?P<date_range>.+)$',
            # Pattern E: Just scan for common position titles
            r'\b(Engineer|Developer|Manager|Director|Coordinator|Consultant|Intern|Analyst|Associate|Specialist)\b'
        ]

        # Job title keywords to help filter legitimate positions
        job_keywords = {"associate", "intern", "consultant", "manager", "engineer", "lead",
                        "analyst", "director", "officer", "specialist", "developer", "designer"}

        lines = text.splitlines()
        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Try patterns A-D first (structured formats)
            for i, pattern in enumerate(patterns[:-1]):
                match = re.match(pattern, line)
                if match:
                    position = match.group("position").strip()
                    # Clean up position (remove monetary values, etc.)
                    position = re.sub(r'\$\d+[,\d]*\.?\d*', '', position)
                    position = re.sub(r'\s+', ' ', position).strip()
                    if position and any(kw in position.lower() for kw in job_keywords):
                        positions.append(position)
                        break

            # If no structured pattern matched, use Pattern E to find job titles
            if not any(p in positions for p in line.split()):
                for match in re.finditer(patterns[-1], line):
                    title = match.group(0)
                    # Make sure it's not just a common word
                    if title.lower() in job_keywords and title not in positions:
                        positions.append(title)

        return positions

    def _enhance_experience_data(self, experience_data: dict, text: str) -> dict:
        """
        Enhances experience data by:
        1. Identifying leadership roles
        2. Normalizing position titles to remove monetary values
        3. Categorizing experiences by type (professional, intern, leadership)
        """
        enhanced = experience_data.copy()

        # Clean up positions to remove monetary values and normalize
        if "positions" in enhanced:
            enhanced["positions"] = [
                re.sub(r'\$\d+[,\d]*\.?\d*', '', pos).strip()
                for pos in enhanced["positions"]
                if not re.match(r'^\$?\d+\.?\d*$', pos.strip())
            ]

        # Identify leadership roles
        leadership_keywords = ["lead", "leader", "chief", "head", "president",
                               "director", "chair", "manager", "supervisor"]

        leadership_roles = []
        for pos in enhanced.get("positions", []):
            if any(keyword in pos.lower() for keyword in leadership_keywords):
                leadership_roles.append(pos)

        enhanced["leadership_roles"] = leadership_roles

        # Check for internships
        internships = enhanced.get("internships", [])
        if not internships:
            internships = [pos for pos in enhanced.get("positions", [])
                           if "intern" in pos.lower()]
            enhanced["internships"] = internships

        # Categorize experiences
        enhanced["experience_types"] = {
            "professional": [p for p in enhanced.get("positions", [])
                             if p not in leadership_roles and p not in internships],
            "leadership": leadership_roles,
            "internships": internships
        }

        return enhanced

    def _enhance_skills_extraction(self, skills: dict, resume_industry: str, target_industry: str) -> dict:
        """
        Enhances extracted skills by:
        1. Removing monetary values incorrectly categorized as skills
        2. Recategorizing misclassified skills
        3. Adding transferability scores for cross-domain skills
        """
        enhanced = skills.copy()

        # Clean up errors list - remove monetary values
        errors = []
        for item in enhanced.get("errors", []):
            skill_name = item.get("skill", "").strip()
            # Skip monetary values
            if re.match(r'^\$?\d+\.?\d*$', skill_name):
                continue
            errors.append(item)
        enhanced["errors"] = errors

        # Add transferability scores for cross-domain applications
        if resume_industry != target_industry:
            # Create a transferable category if it doesn't exist
            if "transferable" not in enhanced:
                enhanced["transferable"] = []

            # Check cross-domain skills from the industry detector
            transferable_skills = self.industry_detector.get_transferable_skills(
                resume_industry, target_industry
            )

            # For skills in any category, check if they're transferable
            for category in enhanced:
                if category in ["errors", "transferable"]:
                    continue

                for i, skill_item in enumerate(enhanced[category]):
                    skill_name = skill_item.get("skill", "").strip().lower()

                    # Check if it's in our transferable skills list
                    if skill_name in transferable_skills:
                        enhanced[category][i]["transferable"] = True
                        enhanced[category][i]["relevance"] = transferable_skills[skill_name]

                        # Add to transferable category as well
                        enhanced["transferable"].append(enhanced[category][i])

        return enhanced

    def _calculate_total_experience_years(self, text: str) -> float:
        """
        Fallback method: scans the experience text for date ranges using a regex that accepts full month names
        (or common abbreviations) for both start and end dates. It then parses these dates and sums the durations.
        """
        # Updated regex:
        pattern = re.compile(
            r'\b(?P<start>(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4})\b\s*(?:-|–|to)\s*\b(?P<end>(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}|Present)\b',
            re.IGNORECASE
        )
        total_days = 0
        for m in pattern.finditer(text):
            start_str = m.group("start")
            end_str = m.group("end")
            try:
                start_date = parse_date(start_str, fuzzy=True)
            except Exception as e:
                logger.debug("Error parsing start date '%s': %s", start_str, e)
                start_date = None
            try:
                if "present" in end_str.lower():
                    end_date = datetime.now()
                else:
                    end_date = parse_date(end_str, fuzzy=True)
            except Exception as e:
                logger.debug("Error parsing end date '%s': %s", end_str, e)
                end_date = None
            if start_date and end_date:
                delta = (end_date - start_date).days
                total_days += delta
        total_years = total_days / 365.25 if total_days else 0.0
        return round(total_years, 2)

    def _extract_contact_info(self, text: str, doc: Optional[spacy.tokens.Doc] = None) -> dict:
        if doc is None:
            doc = self.nlp(text)
        contact_info = {'email': None, 'phone': None, 'linkedin': None, 'location': None}
        email_match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b', text)
        if email_match:
            contact_info['email'] = email_match.group(0)
        phone_match = re.search(r'(?:\+\d{1,2}\s)?\(?\d{2,3}\)?[\s.-]?\d{3}[\s.-]?\d{4}', text)
        if phone_match:
            contact_info['phone'] = phone_match.group(0)
        linkedin_match = re.search(r'(?:https?://)?(?:www\.)?linkedin\.com/in/[A-Za-z0-9_-]+', text, re.IGNORECASE)
        if linkedin_match:
            contact_info['linkedin'] = linkedin_match.group(0)
        for ent in doc.ents:
            if ent.label_ in ("GPE", "LOC"):
                contact_info['location'] = ent.text
                break
        return contact_info

    def _perform_job_matching(self,
                              resume_text: str,
                              resume_skills: dict,
                              resume_experience: dict,
                              resume_industry: str,
                              job_description: str,
                              job_analysis: dict,
                              target_industry: str,
                              industry_cfg: dict) -> dict:
        """
        Performs a comprehensive job matching analysis between a resume and job description.

        Args:
            resume_text: Full text of the resume
            resume_skills: Extracted skills from the resume
            resume_experience: Extracted experience from the resume
            resume_industry: Detected industry of the resume
            job_description: The job description text
            job_analysis: Analyzed job description details
            target_industry: Detected industry of the job
            industry_cfg: Industry configuration for the job

        Returns:
            Dictionary with detailed matching results
        """
        # Flatten skills into a single set for matching
        resume_skills_set = self._flatten_skills_dict(resume_skills)

        # Get job requirements
        job_required = {s.lower() for s in job_analysis.get("requirements", {}).get("must_have", [])}
        job_preferred = {s.lower() for s in job_analysis.get("requirements", {}).get("nice_to_have", [])}

        # Match skills and requirements
        skills_match = self._analyze_skills_match(
            resume_skills_set, job_required, job_preferred,
            resume_industry, target_industry
        )

        # Match experience
        experience_match = self._analyze_experience_match(
            resume_experience, job_analysis, industry_cfg, target_industry
        )

        # Match requirements
        requirements_match = self._analyze_requirements_match(
            resume_text, job_analysis, resume_industry, target_industry
        )

        # Get career transition data if industries differ
        career_transition = None
        if resume_industry != target_industry:
            try:
                # Get career transition map from IndustryAnalysisConfig
                industry_config = IndustryAnalysisConfig()
                career_transition = industry_config.get_career_transition_map(
                    resume_industry, target_industry
                )
            except Exception as e:
                logger.error(f"Error getting career transition data: {str(e)}")

        # Calculate overall match score with industry context
        match_score = self._calculate_overall_match(
            skills_match, experience_match, job_analysis,
            industry_cfg, resume_industry, target_industry
        )

        return {
            "description": job_description,
            "industry": target_industry,
            "resume_industry": resume_industry,
            "requirements_match": requirements_match,
            "skills_match": skills_match,
            "experience_match": experience_match,
            "overall_score": match_score,
            "match_score": f"{match_score * 100:.1f}%",
            "career_transition": career_transition,
            "is_career_transition": resume_industry != target_industry
        }

    def _flatten_skills_dict(self, skills: dict) -> set:
        """
        Flatten the structured skills dictionary into a single set of skill names.
        Also includes skills from transferable and cross_domain categories if present.
        """
        flattened = set()
        for cat_name, skill_list in skills.items():
            if cat_name == "errors":
                continue

            for item in skill_list:
                if isinstance(item, dict) and 'skill' in item:
                    flattened.add(item['skill'].lower())
                elif isinstance(item, str):
                    flattened.add(item.lower())

        return flattened

    def _analyze_skills_match(self,
                              resume_skills: set,
                              job_required: set,
                              job_preferred: set,
                              resume_industry: str,
                              target_industry: str) -> dict:
        """
        Match resume skills against job requirements, considering industry context
        and transferable skills between different domains.

        Args:
            resume_skills: Set of skills found in the resume
            job_required: Set of required skills from the job description
            job_preferred: Set of preferred skills from the job description
            resume_industry: The detected industry of the resume
            target_industry: The detected industry of the job

        Returns:
            A dictionary with detailed skill matching analysis
        """
        # Get industry-specific skills for proper matching
        industry_config = IndustryAnalysisConfig()
        required_skills = industry_config.industry_detector.get_required_skills_for_industry(target_industry)

        # Filter the job requirements to ensure they're relevant to this industry
        filtered_required = {s for s in job_required if s in required_skills}

        # If filtering left too few skills, add domain-specific skills
        if len(filtered_required) < 3:
            # Add common industry skills based on the job description
            industry_skills = set(list(required_skills)[:5])
            filtered_required.update(industry_skills)

        # Find exact matches
        direct_matches = resume_skills & filtered_required
        direct_preferred_matches = resume_skills & job_preferred

        # Find transferable skills
        transferable_skills = set()
        if resume_industry != target_industry:
            # Get transferable skills map
            transferable_map = industry_config.industry_detector.get_transferable_skills(
                resume_industry, target_industry
            )
            # Check if any resume skills are transferable to the target industry
            for skill in resume_skills:
                if skill in transferable_map:
                    transferable_skills.add(skill)

        # Calculate match percentages
        required_match_pct = len(direct_matches) / len(filtered_required) * 100 if filtered_required else 100
        preferred_match_pct = len(direct_preferred_matches) / len(job_preferred) * 100 if job_preferred else 0

        # Calculate transferable skills bonus
        transferable_bonus = 0
        if resume_industry != target_industry and transferable_skills:
            # Add a bonus based on how many transferable skills were found
            transferable_bonus = min(len(transferable_skills) * 5, 20)  # Max 20% bonus

        # Adjust required match percentage with transferable skills bonus
        adjusted_required_pct = min(required_match_pct + transferable_bonus, 100)

        # Return the complete analysis
        return {
            'required': {
                'matched': sorted(direct_matches),
                'missing': sorted(filtered_required - resume_skills),
                'match_percentage': round(required_match_pct, 1),
                'adjusted_percentage': round(adjusted_required_pct, 1)
            },
            'preferred': {
                'matched': sorted(direct_preferred_matches),
                'missing': sorted(job_preferred - resume_skills),
                'match_percentage': round(preferred_match_pct, 1)
            },
            'transferable': {
                'skills': sorted(transferable_skills),
                'bonus_percentage': transferable_bonus
            }
        }

    def _analyze_requirements_match(self, resume_text: str, job_analysis: dict,
                                    resume_industry: str, target_industry: str) -> dict:
        """
        Enhanced requirements matching that accounts for cross-industry terminology
        and filters out irrelevant requirements based on industry context.
        Using shared utilities for industry-specific configuration.
        """
        import string
        translator = str.maketrans('', '', string.punctuation)
        normalized_resume = resume_text.lower().translate(translator)

        # Initialize match structure
        matches = {
            'must_have': [],
            'nice_to_have': [],
            'missing_requirements': [],
            'irrelevant_requirements': []
        }

        # Get raw requirements from job analysis
        all_must_have = job_analysis.get('requirements', {}).get('must_have', [])
        all_nice_to_have = job_analysis.get('requirements', {}).get('nice_to_have', [])

        # Normalize requirements
        req_must = [req.lower().translate(translator).strip() for req in all_must_have]
        req_nice = [req.lower().translate(translator).strip() for req in all_nice_to_have]

        # Filter out requirements not relevant to the target industry
        industry_config = IndustryAnalysisConfig()
        target_skills = industry_config.industry_detector.get_required_skills_for_industry(target_industry)

        # Get skill categories from shared utilities
        target_categories = SKILL_CATEGORIES.get(target_industry, SKILL_CATEGORIES.get("general", {}))

        # Filter requirements through industry-specific lens
        filtered_must = []
        irrelevant_must = []

        # Instead of hardcoding exclusions, use industry configs to determine relevance
        for req in req_must:
            # First check if it's found in other industry skill sets (excluding current)
            is_exclusive_to_other_industry = False

            # Check if this requirement is strongly associated with a different industry
            for ind, cats in SKILL_CATEGORIES.items():
                if ind != target_industry:
                    for cat, skills in cats.items():
                        if isinstance(skills, list) and any(skill.lower() in req for skill in skills):
                            # If this requirement matches a skill from a different industry
                            # and doesn't appear in the target industry skills
                            if not any(skill.lower() in req for skill in target_skills):
                                is_exclusive_to_other_industry = True
                                break

                if is_exclusive_to_other_industry:
                    break

            if is_exclusive_to_other_industry:
                irrelevant_must.append(req)
            elif req in target_skills or any(term.lower() in req for term in target_skills):
                filtered_must.append(req)
            elif any(common_term in req for common_term in ["experience", "communication", "teamwork", "leadership"]):
                # Common terms that apply across domains
                filtered_must.append(req)
            else:
                # If we can't determine relevance, include it for safety
                filtered_must.append(req)

        # Process the filtered requirements
        for req in filtered_must:
            if req in normalized_resume:
                matches['must_have'].append(req)
            else:
                matches['missing_requirements'].append(req)

        # Process nice-to-have requirements (less strict filtering)
        for req in req_nice:
            if req in normalized_resume:
                matches['nice_to_have'].append(req)

        # Add irrelevant requirements to the matches
        matches['irrelevant_requirements'] = irrelevant_must

        return matches

    def _analyze_experience_match(self, resume_experience: dict, job_analysis: dict,
                                  industry_cfg: dict, target_industry: str) -> dict:
        """
        Enhanced experience matching that considers:
        1. Years of experience
        2. Role relevance to target industry
        3. Leadership experience
        4. Internship experience in relevant fields

        Using shared utilities for industry-specific keywords.
        """
        # Get job level and required years
        job_level = job_analysis.get('experience_level', 'entry').lower()
        resume_years = resume_experience.get('total_years', 0.0)
        required_years_map = industry_cfg.get('experience_levels', {'entry': 0, 'junior': 1, 'mid': 3, 'senior': 5})
        req_years = required_years_map.get(job_level, 0)

        # Basic experience match
        meets_req = resume_years >= req_years
        exp_weight = industry_cfg.get('experience_weight', 0.3)
        basic_score = min(resume_years / req_years, 1.0) * exp_weight if req_years > 0 else exp_weight

        # Get positions/roles from resume
        positions = resume_experience.get('positions', [])
        leadership_roles = resume_experience.get('leadership_roles', [])
        internships = resume_experience.get('internships', [])

        # Use industry-specific keywords from INDUSTRY_CONFIGS
        target_industry_keywords = []

        # Extract keywords from the target industry config
        if target_industry in INDUSTRY_CONFIGS:
            # Get keywords directly from industry config
            target_industry_keywords.extend(INDUSTRY_CONFIGS[target_industry].get('keywords', []))

            # Get experience patterns which often contain relevant role terms
            for pattern in INDUSTRY_CONFIGS[target_industry].get('experience_patterns', []):
                # Extract words from patterns (removing regex special chars)
                pattern_words = re.findall(r'\b(\w+)\b', pattern)
                target_industry_keywords.extend(pattern_words)

        # If no keywords found, fall back to general terms
        if not target_industry_keywords:
            target_industry_keywords = ["management", "coordination", "leadership", "project",
                                        "planning", "analysis", "development", "implementation"]

        # Calculate position relevance
        relevant_positions = 0
        for position in positions:
            position_lower = position.lower()
            if any(keyword.lower() in position_lower for keyword in target_industry_keywords):
                relevant_positions += 1

        position_relevance = relevant_positions / len(positions) if positions else 0

        # Calculate leadership bonus
        leadership_bonus = 0
        if leadership_roles:
            leadership_bonus = min(len(leadership_roles) * 0.05, 0.15)  # Up to 15% bonus

        # Calculate internship relevance for entry-level positions
        internship_bonus = 0
        relevant_internships = 0
        if job_level in ['entry', 'junior'] and internships:
            for internship in internships:
                if any(keyword.lower() in internship.lower() for keyword in target_industry_keywords):
                    relevant_internships += 1

            internship_bonus = min(relevant_internships * 0.1, 0.2)  # Up to 20% bonus

        # Calculate final score with bonuses
        position_score = position_relevance * 0.2  # Up to 20% from position relevance
        final_score = basic_score + leadership_bonus + internship_bonus + position_score
        final_score = round(min(final_score, 1.0), 2)  # Cap at 1.0 and round

        return {
            'meets_requirements': meets_req,
            'years_required': req_years,
            'years_actual': resume_years,
            'relevant_positions': relevant_positions,
            'leadership_roles': len(leadership_roles),
            'relevant_internships': relevant_internships,
            'experience_match_score': final_score,
            'leadership_bonus': leadership_bonus,
            'internship_bonus': internship_bonus,
            'position_relevance_score': position_score
        }

    def _calculate_overall_match(self, skills_match: dict, experience_match: dict,
                                 job_analysis: dict, industry_cfg: dict = None,
                                 resume_industry: str = None, target_industry: str = None) -> float:
        """
        Enhanced matching algorithm that accounts for:
        1. Industry relevance and career transitions
        2. Transferable skills
        3. Dynamic weighting based on job requirements
        4. Balanced scoring for career changers

        Uses shared utilities for industry configurations.
        """
        # Get base weights from industry config or INDUSTRY_CONFIGS
        weights = {}

        if industry_cfg and 'weights' in industry_cfg:
            weights = industry_cfg.get('weights')
        elif target_industry in INDUSTRY_CONFIGS:
            weights = INDUSTRY_CONFIGS[target_industry].get('section_weights', {})

        # If no weights were found, use default weights
        if not weights:
            weights = {
                'skills': 0.4,
                'experience': 0.3,
                'education': 0.3
            }

        # Adjust weights for career transitions using industry relationships from shared utilities
        if resume_industry and target_industry and resume_industry != target_industry:
            # Check if industries are related using IndustryDetector
            industry_detector = IndustryDetector()
            are_related = False

            if hasattr(industry_detector, 'related_domains') and resume_industry in industry_detector.related_domains:
                are_related = target_industry in industry_detector.related_domains[resume_industry]

            # For career changers, adjust weights based on relatedness
            if are_related:
                # For related domains, make smaller adjustments
                transition_weights = {
                    'skills': weights['skills'] * 1.1,  # Slight increase for skills
                    'experience': weights['experience'] * 0.9,  # Slight decrease for experience
                    'education': weights['education'] * 1.05  # Very slight increase for education
                }
            else:
                # For unrelated domains, make larger adjustments
                transition_weights = {
                    'skills': weights['skills'] * 1.2,  # Larger increase for skills
                    'experience': weights['experience'] * 0.8,  # Larger decrease for experience
                    'education': weights['education'] * 1.1  # Larger increase for education
                }

            # Normalize weights to sum to 1.0
            total = sum(transition_weights.values())
            weights = {k: v / total for k, v in transition_weights.items()}

        # Calculate skills score using both direct matches and transferable skills
        skills_req_score = skills_match.get('required', {}).get('adjusted_percentage', 0.0) / 100
        skills_pref_score = skills_match.get('preferred', {}).get('match_percentage', 0.0) / 100

        # Weight required skills higher than preferred
        skills_score = (skills_req_score * 0.7) + (skills_pref_score * 0.3)

        # Get experience score with all bonuses included
        exp_score = experience_match.get('experience_match_score', 0.0)

        # Calculate education score
        has_education = job_analysis.get('education_requirements', False)

        # Look for relevant education based on target industry
        relevant_degree = False
        if target_industry in INDUSTRY_CONFIGS:
            # Check if education requirements are specified in industry config
            required_education = INDUSTRY_CONFIGS[target_industry].get('required_sections', [])
            relevant_degree = 'education' in required_education

        if has_education:
            edu_score = 1.0  # Has relevant education
        elif relevant_degree:
            edu_score = 0.8  # Has degree but not exactly what's required
        else:
            edu_score = 0.5  # Has some education

        # Calculate transferable skills bonus using shared utilities
        transferable_bonus = 0.0
        if resume_industry and target_industry and resume_industry != target_industry:
            # Check if they have transferable skills
            transferable_skills = skills_match.get('transferable', {}).get('skills', [])

            # Get a boost based on the number of transferable skills
            if transferable_skills:
                # Use constants from GENERAL_FEEDBACK_RULES if available
                if 'ml_suggestions' in GENERAL_FEEDBACK_RULES:
                    max_transferable_bonus = GENERAL_FEEDBACK_RULES['ml_suggestions'].get('max_skills', 3) * 0.033
                else:
                    max_transferable_bonus = 0.1  # Default max 10% bonus

                transferable_bonus = min(len(transferable_skills) * 0.02, max_transferable_bonus)

        # NEW: Programming skills + projects bonus
        # Weight Adjustment for Transferable Skills (if programming skills + projects)
        programming_skills_present = False

        # Check for programming skills in a more robust way
        if 'programming' in skills_match:
            programming_skills_present = len(skills_match['programming']) > 0
        else:
            # Check all categories for programming-related skills
            for category, skills_list in skills_match.items():
                if category in ['errors', 'general']:
                    continue

                # Look for programming keywords in skills
                programming_keywords = ["python", "java", "javascript", "c++", "programming", "coding"]

                if isinstance(skills_list, list) and any(
                        any(kw in str(skill).lower() for kw in programming_keywords)
                        for skill in skills_list
                ):
                    programming_skills_present = True
                    break

        # Check if projects section exists with substantial content
        projects_present = False
        if 'sections' in job_analysis and 'projects' in job_analysis.get('sections', {}):
            projects_content = job_analysis['sections']['projects']
            projects_present = len(projects_content) > 100  # Check if projects section has substantial content

        # Determine transferable skill boost
        transferable_skill_boost = 0.05 if programming_skills_present and projects_present else 0.0
        logger.debug(
            f"Programming skills present: {programming_skills_present}, Projects present: {projects_present}, Boost: {transferable_skill_boost}")

        # Calculate final score with all components
        final_score = (skills_score * weights['skills'] +
                       exp_score * weights['experience'] +
                       edu_score * weights['education'] +
                       transferable_bonus +
                       transferable_skill_boost)

        # Ensure score is between 0 and 1
        final_score = max(0.0, min(1.0, final_score))

        return round(final_score, 2)

    def _filter_skills_extraction(self, skills: dict) -> dict:
        """
        Enhanced skill filtering that:
        1. Properly categorizes soft skills from errors
        2. Handles cross-domain skills appropriately
        3. Adds transferability information for career transitions

        Uses shared utilities for skill categories.
        """
        filtered = skills.copy()

        # Extract categories
        errors = filtered.get("errors", [])
        general = filtered.get("general", [])

        # Get soft skills from shared utilities
        soft_skills = set()
        if "general" in SKILL_CATEGORIES:
            for category in ["communication", "interpersonal_skills", "organization"]:
                if category in SKILL_CATEGORIES["general"]:
                    soft_skills.update(SKILL_CATEGORIES["general"][category])

        # If soft skills not found in shared utilities, use a fallback set
        if not soft_skills:
            soft_skills = {
                "communication", "teamwork", "leadership", "problem solving",
                "critical thinking", "adaptability", "time management",
                "collaboration", "creativity", "emotional intelligence"
            }

        # Process error entries
        new_errors = []
        for entry in errors:
            skill_text = entry.get("skill", "").lower()

            # Move soft skills to general category
            if skill_text in soft_skills or any(soft in skill_text for soft in soft_skills):
                general.append(entry)
            # Keep technical errors in errors category
            else:
                new_errors.append(entry)

        # Update the categories
        filtered["errors"] = new_errors
        filtered["general"] = general

        # Process cross-domain category if it exists
        if "cross_domain" in filtered:
            cross_domain = filtered.get("cross_domain", [])

            # Ensure cross-domain skills have transferability information
            for i, entry in enumerate(cross_domain):
                if "transferable" not in entry:
                    cross_domain[i]["transferable"] = True
                if "relevance" not in entry:
                    cross_domain[i]["relevance"] = 0.7  # Default high relevance for cross-domain skills

            filtered["cross_domain"] = cross_domain

        return filtered


# Instantiate the analyzer so that other modules can import and use it.
analyzer = ResumeAnalyzer()