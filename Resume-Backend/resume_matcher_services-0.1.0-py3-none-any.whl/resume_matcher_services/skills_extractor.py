import re
import spacy
import logging
from typing import Dict, List, Set, Optional
from fuzzywuzzy import fuzz
from spacy.matcher import PhraseMatcher
from spacy.util import filter_spans
from .shared_utilities import load_config, SKILL_CATEGORIES, TECH_SYNONYMS, KNOWN_SKILLS, INDUSTRY_SYNONYMS

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
if not logger.handlers:
    logger.addHandler(handler)


class SkillsExtractor:
    def __init__(self, nlp: spacy.language.Language = None, config: dict = None):
        """
        Initializes the SkillsExtractor.

        :param nlp: A spaCy language model. If not provided, a default model is loaded.
        :param config: A configuration dictionary. Defaults to an empty dict if not provided.
        """
        # Use provided NLP model or load a default transformer-based model.
        self.nlp = nlp or spacy.load("en_core_web_trf", exclude=["lemmatizer", "ner"])
        self.config = config or {}  # You can extend this later if needed.

        # Build the PhraseMatcher for skill extraction.
        self.matcher = PhraseMatcher(self.nlp.vocab, attr="LOWER")
        # Combine known skills and synonyms, then normalize them.
        all_syns = list(TECH_SYNONYMS.keys()) + list(TECH_SYNONYMS.values())
        self.normalized_skills = set(self.normalize_skill(s) for s in (KNOWN_SKILLS + all_syns))
        patterns = [self.nlp.make_doc(skill) for skill in self.normalized_skills if skill]
        self.matcher.add("SKILLS", patterns)

        # Build an internal skill database for quick lookup.
        self._build_skill_db()

        # Create cross-domain skill mappings for related fields
        self._build_cross_domain_mappings()

        # Initialize fuzzy matching threshold
        self.fuzzy_threshold = 85  # Higher threshold for more precise matches

    def _build_skill_db(self):
        self.skill_terms = set()
        all_terms = list(TECH_SYNONYMS.keys()) + KNOWN_SKILLS
        all_terms.sort(key=lambda x: len(x.split()), reverse=True)
        for term in all_terms:
            self.skill_terms.add(self.normalize_skill(term))

    def _build_cross_domain_mappings(self):
        """
        Creates mappings between related skills in different domains.
        This helps with identifying transferable skills between disciplines.
        """
        self.cross_domain_skills = {
            # Programming skills relevant to multiple industries
            "python": ["data_analysis", "automation", "modeling", "simulation"],
            "java": ["software_development", "automation", "systems_design"],
            "c++": ["simulation", "systems_programming", "performance_optimization"],
            "matlab": ["data_analysis", "modeling", "signal_processing", "simulation"],
            "r": ["statistics", "data_analysis", "data_visualization", "machine_learning"],
            "sql": ["database_management", "data_analysis", "data_storage"],

            # Tools/technologies with cross-domain applications
            "cad": ["design", "modeling", "drafting", "visualization"],
            "gis": ["spatial_analysis", "mapping", "data_visualization"],
            "excel": ["data_analysis", "financial_modeling", "reporting", "data_management"],
            "tableau": ["data_visualization", "business_intelligence", "reporting"],
            "powerbi": ["data_visualization", "business_intelligence", "reporting"],

            # Project management skills
            "agile": ["project_management", "scrum", "kanban", "team_collaboration"],
            "scrum": ["project_management", "agile", "sprint_planning", "team_management"],
            "jira": ["project_tracking", "issue_management", "workflow_automation"],

            # General professional skills
            "project_management": ["planning", "coordination", "resource_allocation"],
            "data_analysis": ["data_interpretation", "statistics", "reporting", "problem_solving"],
            "communication": ["presentation", "documentation", "client_interaction", "reporting"],
            "design": ["conceptualization", "specification", "validation"],
            "analysis": ["evaluation", "assessment", "calculation"],
            "testing": ["validation", "verification", "quality_assurance"],
            "documentation": ["technical_writing", "specification", "reporting"]
        }

        # Create a dictionary to map related domains
        self.related_domains = {
            "technology": ["engineering", "data_science", "information_technology"],
            "engineering": ["technology", "manufacturing", "construction", "design"],
            "healthcare": ["medicine", "biotechnology", "life_sciences", "pharmaceutical"],
            "finance": ["accounting", "investment_banking", "financial_services", "insurance"],
            "business": ["marketing", "sales", "operations", "strategy", "consulting"],
            "education": ["teaching", "curriculum_development", "e_learning", "education_technology"],
            "creative": ["design", "media", "advertising", "content_creation", "entertainment"],
            "science": ["research", "laboratory", "environmental_science", "chemistry", "physics"],
            "legal": ["law", "compliance", "regulatory", "contracts", "intellectual_property"],
            "data_science": ["machine_learning", "analytics", "ai", "statistics", "data_engineering"]
        }

    def get_transferable_skills(self, skill: str, source_domain: str, target_domain: str) -> List[str]:
        """
        Identifies transferable aspects of a skill between different domains.

        Args:
            skill: The skill to find transferable aspects for
            source_domain: The domain where the skill is currently classified
            target_domain: The domain to transfer the skill to

        Returns:
            List of transferable concepts/skills
        """
        norm_skill = self.normalize_skill(skill).lower()

        # Direct transferable skills from cross-domain mapping
        transferable = self.cross_domain_skills.get(norm_skill, [])

        # Check if domains are related
        if source_domain in self.related_domains and target_domain in self.related_domains[source_domain]:
            relevance = 0.7  # High relevance between related domains
        else:
            relevance = 0.3  # Lower relevance for unrelated domains

        return transferable, relevance

    def normalize_skill(self, skill: str) -> str:
        """
        Normalizes a skill string to its canonical form.
        Steps:
          1. Strip whitespace.
          2. Remove trailing version numbers (e.g. "Python 3.8" -> "Python").
          3. Replace with canonical form if a synonym exists.
          4. Remove unwanted punctuation (while preserving symbols like '+' and '#').
          5. Return in title case.
        """
        raw = skill.strip()
        if not raw:
            return ""
        # Remove trailing version numbers.
        no_version = re.sub(r"\s+\d+(\.\d+)?", "", raw).strip()
        lower_no_version = no_version.lower()
        if lower_no_version in TECH_SYNONYMS:
            # For example, "node js" -> "Node.js"
            return TECH_SYNONYMS[lower_no_version].title()
        skill_clean = re.sub(r"[^\w\s#+]", "", no_version).strip()
        return skill_clean.title()

    def _preprocess_text(self, text: str) -> str:
        """
        Preprocesses the input text, replacing synonyms with their canonical forms.
        """
        sorted_synonyms = sorted(TECH_SYNONYMS.keys(), key=len, reverse=True)
        processed = text
        for syn in sorted_synonyms:
            canon = TECH_SYNONYMS[syn]
            pattern = re.compile(r"\b" + re.escape(syn) + r"\b", re.IGNORECASE)

            def replace_with_canonical(match):
                if " " in canon and not any(c.isupper() for c in canon[1:]):
                    return canon.title()
                return canon

            new_processed = pattern.sub(replace_with_canonical, processed)
            if new_processed != processed:
                logger.debug(f"Replaced '{syn}' -> '{canon}'")
                processed = new_processed
        return processed

    def extract_skill_context(self, text: str) -> List[dict]:
        doc = self.nlp(text)
        matches = self.matcher(doc)
        spans = filter_spans([doc[start:end] for _, start, end in matches])
        results = []
        for span in spans:
            # Get the sentence in which the skill appears.
            context = span.sent.text.strip()
            results.append({
                "skill": span.text,
                "context": context
            })
        return results

    def _find_duration(self, doc, start: int, end: int) -> Optional[str]:
        window_size = 5
        search_start = max(0, start - window_size)
        search_end = min(len(doc), end + window_size)
        durations = []
        for i in range(search_start, search_end - 1):
            tok1 = doc[i]
            tok2 = doc[i + 1]
            if tok1.like_num and tok2.text.lower() in {"year", "years", "month", "months"}:
                durations.append((tok1.text, i))
        if not durations:
            return None
        # Pick the closest to the skill
        skill_center = (start + end) / 2.0
        best_dur = None
        best_dist = None
        for num_str, idx in durations:
            try:
                num = float(num_str)
                dist = abs(idx - skill_center)
                if best_dist is None or dist < best_dist:
                    best_dist = dist
                    best_dur = num_str
            except ValueError:
                continue
        return best_dur

    def match_skill(self, skill: str, known_skills: List[str], threshold: int = 80) -> Optional[str]:
        normalized_skill = self.normalize_skill(skill)
        exact_matches = [ks for ks in known_skills if self.normalize_skill(ks) == normalized_skill]
        if exact_matches:
            return exact_matches[0]
        best_match = None
        highest_score = 0
        for ks in known_skills:
            score = fuzz.ratio(normalized_skill, self.normalize_skill(ks))
            if score > highest_score:
                best_match = ks
                highest_score = score
        if highest_score >= threshold:
            return best_match
        logger.debug(f"No strong match found for '{skill}' (score: {highest_score}).")
        return None

    def fuzzy_match_domain_specific(self, skill: str, domain: str, threshold: int = 75) -> Optional[str]:
        """
        Performs fuzzy matching focused on domain-specific tools and technologies.

        Args:
            skill: The skill text to match
            domain: The industry domain to focus matching on
            threshold: Minimum fuzzy match score to accept

        Returns:
            Matched canonical skill name or None
        """
        domain = domain.lower()
        domain_skills = set()

        # Get skills specifically for this domain
        if domain in SKILL_CATEGORIES:
            for category, skills_list in SKILL_CATEGORIES[domain].items():
                if isinstance(skills_list, list):
                    domain_skills.update([self.normalize_skill(s) for s in skills_list])

        # Also check related domains
        for related_domain in self.related_domains.get(domain, []):
            if related_domain in SKILL_CATEGORIES:
                for category, skills_list in SKILL_CATEGORIES[related_domain].items():
                    if isinstance(skills_list, list):
                        domain_skills.update([self.normalize_skill(s) for s in skills_list])

        # Perform fuzzy matching within the domain-specific skills
        normalized_skill = self.normalize_skill(skill)
        best_match = None
        highest_score = 0

        for domain_skill in domain_skills:
            # Try exact match first
            if normalized_skill.lower() == domain_skill.lower():
                return domain_skill

            # Then try fuzzy match
            score = fuzz.ratio(normalized_skill.lower(), domain_skill.lower())
            if score > highest_score:
                highest_score = score
                best_match = domain_skill

        if highest_score >= threshold:
            logger.debug(f"Domain-specific match: '{skill}' -> '{best_match}' (score: {highest_score})")
            return best_match

        return None

    def _get_industry_skills(self, industry: str) -> Set[str]:
        """
        Returns the set of normalized skill strings for the given industry.
        If the industry is not found, defaults to 'technology'.
        """
        industry = industry.lower()
        categories = SKILL_CATEGORIES.get(industry, SKILL_CATEGORIES.get("technology", {}))
        skills = set()

        # Get skills from the specific industry categories
        for cat_skills in categories.values():
            if isinstance(cat_skills, list):
                for skill in cat_skills:
                    normalized = self.normalize_skill(skill).lower()
                    if normalized:
                        skills.add(normalized)

        # Also add skills from related domains to broaden matching
        for related_domain in self.related_domains.get(industry, []):
            related_categories = SKILL_CATEGORIES.get(related_domain, {})
            for cat_skills in related_categories.values():
                if isinstance(cat_skills, list):
                    for skill in cat_skills:
                        normalized = self.normalize_skill(skill).lower()
                        if normalized:
                            skills.add(normalized)

        # Include technology synonyms as they're broadly applicable
        for syn in TECH_SYNONYMS.keys():
            normalized_syn = self.normalize_skill(syn).lower()
            if normalized_syn:
                skills.add(normalized_syn)

        logger.debug(f"Normalized industry skills for '{industry}': {len(skills)} skills collected")
        return skills

    def is_cross_domain_skill(self, skill: str) -> bool:
        """
        Checks if a skill is applicable across multiple domains.
        """
        normalized = self.normalize_skill(skill).lower()
        return normalized in self.cross_domain_skills

    def determine_skill_relevance(self, skill: str, source_industry: str, target_industry: str) -> float:
        """
        Determines how relevant a skill is when transferring between industries.
        Returns a relevance score between 0 and 1.
        """
        # Direct match in target industry
        target_skills = self._get_industry_skills(target_industry)
        if self.normalize_skill(skill).lower() in target_skills:
            return 1.0

        # Cross-domain skill
        if self.is_cross_domain_skill(skill):
            return 0.8

        # Related domain
        if (source_industry in self.related_domains and
                target_industry in self.related_domains.get(source_industry, [])):
            return 0.6

        # Default low relevance
        return 0.3

    def get_skill_category(self, skill: str, industry: str) -> Optional[str]:
        """
        Determines the most appropriate category for a skill within an industry.
        Also checks related domains for cross-discipline skills.
        """
        normalized_skill = self.normalize_skill(skill).lower()

        # Check primary industry first
        for category, cat_skills in SKILL_CATEGORIES.get(industry.lower(), {}).items():
            normalized_cat_skills = [self.normalize_skill(s).lower() for s in cat_skills]
            if normalized_skill in normalized_cat_skills:
                return category

        # If not found, check related domains
        for related_domain in self.related_domains.get(industry.lower(), []):
            for category, cat_skills in SKILL_CATEGORIES.get(related_domain, {}).items():
                normalized_cat_skills = [self.normalize_skill(s).lower() for s in cat_skills]
                if normalized_skill in normalized_cat_skills:
                    return f"{category} (transferable from {related_domain})"

        # Check for cross-domain skills
        if normalized_skill in self.cross_domain_skills:
            return "cross_domain"

        return None

    def extract_skills(self, text: str, industry: str = "technology", target_job: str = None) -> Dict[str, List[dict]]:
        """
        Extracts skills from the provided text, categorizes them using SKILL_CATEGORIES.
        Accounts for cross-domain skills and transferable skills if target_job is provided.

        Args:
            text: The text to extract skills from
            industry: The primary industry context for skill extraction
            target_job: Optional job description to help with skill relevance

        Returns:
            Dictionary with skill categories and lists of skills
        """
        if not isinstance(text, str) or not text.strip():
            logger.error("Skill extraction failed: Input must be a non-empty string")
            cats = SKILL_CATEGORIES.get(industry.lower(), SKILL_CATEGORIES["general"])
            result = {cat: [] for cat in cats}
            result["general"] = []
            result["errors"] = ["Skill extraction failed due to invalid input"]
            return result

        # Determine target industry if a job description is provided
        target_industry = industry
        if target_job:
            # In a real implementation, use a more sophisticated detector
            # This is a placeholder for basic detection
            for ind in self.related_domains.keys():
                if ind.lower() in target_job.lower():
                    target_industry = ind
                    break

        # Set up result structure
        source_cats = SKILL_CATEGORIES.get(industry.lower(), SKILL_CATEGORIES["technology"])
        target_cats = SKILL_CATEGORIES.get(target_industry.lower(), source_cats)

        # Initialize result categories
        result = {}
        # Include all source and target categories
        for cat in source_cats:
            if cat not in ["errors", "general"]:
                result[cat] = []

        for cat in target_cats:
            if cat not in ["errors", "general"] and cat not in result:
                result[cat] = []

        # Always include these common categories
        result["general"] = []
        result["cross_domain"] = []  # For skills that apply across domains
        result["programming"] = []  # Common programming skills category
        result["errors"] = []

        try:
            pre_text = self._preprocess_text(text)
            raw_skills = self.extract_skill_context(pre_text)
            logger.debug(f"Raw extracted skills: {len(raw_skills)} skills extracted from text")
        except Exception as e:
            logger.error(f"Skill extraction error: {str(e)}")
            result["errors"].append("Skill extraction process encountered an issue")
            return result

        # Get industry-specific skills for both source and target domains
        source_skills = self._get_industry_skills(industry)
        target_skills = self._get_industry_skills(target_industry) if target_industry != industry else source_skills

        # Process each raw skill using the hierarchical categorization approach
        for sk in raw_skills:
            skill_name = sk.get("skill", "").strip()
            if not skill_name:
                logger.debug("Skipping empty skill name.")
                continue

            normalized_skill = self.normalize_skill(skill_name).lower()
            sk["skill"] = self.normalize_skill(skill_name)  # Update with normalized form

            # Try to place the skill in appropriate categories using a hierarchical approach
            placed = False

            # STEP 1: Try specific industry category first (highest priority)
            specific_cats = SKILL_CATEGORIES.get(industry.lower(), {})
            for cat_name, cat_skills in specific_cats.items():
                if cat_name in ["errors", "general"]:
                    continue

                if isinstance(cat_skills, list):
                    normalized_cat_skills = {self.normalize_skill(s).lower() for s in cat_skills}
                    if normalized_skill in normalized_cat_skills:
                        result[cat_name].append(sk)
                        placed = True
                        logger.debug(f"Placed '{normalized_skill}' in industry category '{cat_name}'")
                        break

            # STEP 2: If not placed, check if it's a cross-domain skill (medium priority)
            if not placed and self.is_cross_domain_skill(normalized_skill):
                sk["transferable"] = True
                transferable_aspects, relevance = self.get_transferable_skills(
                    normalized_skill, industry, target_industry
                )
                sk["relevance"] = relevance
                sk["transferable_aspects"] = transferable_aspects
                result["cross_domain"].append(sk)
                placed = True
                logger.debug(f"Placed '{normalized_skill}' in 'cross_domain' category")

            # STEP 3: If not placed, try programming/common technical skills (often transferable)
            if not placed:
                programming_skills = []
                if "programming" in SKILL_CATEGORIES.get("technology", {}):
                    programming_skills = SKILL_CATEGORIES["technology"]["programming"]

                normalized_prog_skills = {self.normalize_skill(s).lower() for s in programming_skills}
                if normalized_skill in normalized_prog_skills:
                    sk["transferable"] = True
                    result["programming"].append(sk)
                    placed = True
                    logger.debug(f"Placed '{normalized_skill}' in 'programming' category")

            # STEP 4: If not placed and targeting different industry, check target industry
            if not placed and target_industry != industry:
                target_specific_cats = SKILL_CATEGORIES.get(target_industry.lower(), {})
                for cat_name, cat_skills in target_specific_cats.items():
                    if cat_name in ["errors", "general"]:
                        continue

                    if isinstance(cat_skills, list):
                        normalized_cat_skills = {self.normalize_skill(s).lower() for s in cat_skills}
                        if normalized_skill in normalized_cat_skills:
                            sk["transferable"] = True
                            sk["relevance"] = 1.0  # Direct match in target industry

                            # Ensure category exists
                            if cat_name not in result:
                                result[cat_name] = []

                            result[cat_name].append(sk)
                            placed = True
                            logger.debug(f"Placed '{normalized_skill}' in target industry category '{cat_name}'")
                            break

            # STEP 5: If not placed, try fuzzy matching (lower priority)
            if not placed:
                highest_score = 0
                best_category = None
                best_match = None

                # Try fuzzy matching with skills from both source and target industries
                for current_industry in [industry, target_industry]:
                    current_cats = SKILL_CATEGORIES.get(current_industry.lower(), {})
                    for cat_name, cat_skills in current_cats.items():
                        if cat_name in ["errors", "general"] or not isinstance(cat_skills, list):
                            continue

                        for cat_skill in cat_skills:
                            score = fuzz.ratio(normalized_skill, self.normalize_skill(cat_skill).lower())
                            if score > highest_score and score >= self.fuzzy_threshold:
                                highest_score = score
                                best_category = cat_name
                                best_match = cat_skill
                                if current_industry == target_industry and current_industry != industry:
                                    sk["transferable"] = True

                if best_category and best_match:
                    sk["skill"] = self.normalize_skill(best_match)  # Use the canonical form
                    sk["match_score"] = highest_score

                    # Ensure category exists
                    if best_category not in result:
                        result[best_category] = []

                    result[best_category].append(sk)
                    placed = True
                    logger.debug(f"Placed '{normalized_skill}' in '{best_category}' via fuzzy matching")

            # STEP 6: If still not placed, decide between general and errors (lowest priority)
            if not placed:
                # If skill normalization succeeded and seems valid, put in general
                if normalized_skill:
                    result["general"].append(sk)
                    logger.debug(f"Placed '{normalized_skill}' in 'general' as fallback")
                else:
                    # Only put in errors if normalization failed completely
                    result["errors"].append(sk)
                    logger.debug(f"Could not normalize '{skill_name}', adding to errors")

        # Deduplicate skills within each category
        for cat_name in result:
            seen = set()
            unique_skills = []
            for skill_entry in result[cat_name]:
                norm_low = skill_entry["skill"].lower()
                if norm_low not in seen:
                    seen.add(norm_low)
                    unique_skills.append(skill_entry)
            result[cat_name] = unique_skills

        return result