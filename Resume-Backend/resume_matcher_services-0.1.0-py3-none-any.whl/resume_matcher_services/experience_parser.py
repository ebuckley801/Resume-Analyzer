import re
import spacy
import logging
from datetime import datetime
from dateutil import parser as date_parser

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class ExperienceParser:
    def __init__(self, nlp: spacy.language.Language, config: dict):
        self.nlp = nlp
        self.config = config
        # Lookup table for job titles from configuration (if needed)
        self.job_title_lookup = {title.lower() for title in config.get("job_title_lookup", [])}
        # Company suffix whitelist
        self.company_suffixes = ["inc", "corp", "llc", "ltd", "co"]
        # Job title keywords for better recognition
        self.job_title_keywords = [
            "engineer", "developer", "manager", "associate", "analyst", "director",
            "coordinator", "specialist", "intern", "consultant", "lead", "supervisor",
            "assistant", "head", "chief", "president", "vice president", "vp", "ceo", "cto",
            "officer", "administrator", "executive", "researcher", "scientist", "designer",
            "technician", "representative", "advisor", "strategist", "architect"
        ]
        # Leadership role keywords
        self.leadership_keywords = [
            "president", "vice president", "vp", "chair", "director", "head",
            "leader", "captain", "chief", "coordinator", "manager", "lead", "executive"
        ]

    def _extract_date_ranges(self, text: str) -> list:
        date_ranges = []
        # Enhanced patterns for dates with more formats
        patterns = [
            # Standard formats: "Feb 2021 - Present" or "February 2021 - March 2022"
            r'(\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|'
            r'Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{4})\s*(?:-|–|to)\s*([\w\s]+?\d{4}|Present)',

            # Year range format: "2018 - 2020"
            r'(\d{4})\s*(?:-|–|to)\s*(\d{4}|Present)',

            # MM/YYYY format: "01/2018 - 06/2020" or "1/2018 - Present"
            r'(\d{1,2}/\d{4})\s*(?:-|–|to)\s*(\d{1,2}/\d{4}|Present)',

            # YYYY-MM format: "2018-01 to 2020-06"
            r'(\d{4}-\d{2})\s*(?:to|through|until|[-–])\s*(\d{4}-\d{2}|Present)',

            # Season format: "Summer 2019 - Fall 2020"
            r'((?:Spring|Summer|Fall|Winter)\s+\d{4})\s*(?:-|–|to)\s*((?:Spring|Summer|Fall|Winter)\s+\d{4}|Present)'
        ]

        for pattern in patterns:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                part1 = m.group(1)
                part2 = m.group(2)
                try:
                    # Use fuzzy=True with appropriate validation
                    start_date = date_parser.parse(part1, fuzzy=True)

                    # Validate parsed date has reasonable year (1950-2030)
                    if not (1950 <= start_date.year <= 2030):
                        logger.debug(f"Date parsing found unreasonable year: {start_date.year} in '{part1}'")
                        start_date = None
                except Exception as e:
                    logger.debug(f"Date parsing failed for '{part1}': {e}")
                    start_date = None

                try:
                    if re.search(r'present', part2, re.IGNORECASE):
                        end_date = datetime.now()
                    else:
                        end_date = date_parser.parse(part2, fuzzy=True)
                        # Validate end date year
                        if not (1950 <= end_date.year <= 2030):
                            logger.debug(f"Date parsing found unreasonable year: {end_date.year} in '{part2}'")
                            end_date = None
                except Exception as e:
                    logger.debug(f"Date parsing failed for '{part2}': {e}")
                    end_date = None

                # Validate dates – if end_date < start_date, swap them.
                if start_date and end_date and end_date < start_date:
                    start_date, end_date = end_date, start_date

                if start_date and end_date:
                    date_ranges.append({
                        "start": start_date,
                        "end": end_date,
                        "text": m.group(0),
                        "start_text": part1,
                        "end_text": part2
                    })

        return date_ranges

    def _calculate_total_years(self, date_ranges: list) -> float:
        if not date_ranges:
            return 0.0
        # Merge overlapping ranges and calculate duration in years.
        sorted_ranges = sorted(date_ranges, key=lambda x: x["start"])
        merged = []
        current = sorted_ranges[0]
        for r in sorted_ranges[1:]:
            if r["start"] <= current["end"]:
                current["end"] = max(current["end"], r["end"])
            else:
                merged.append(current)
                current = r
        merged.append(current)
        total_days = sum((r["end"] - r["start"]).days for r in merged)
        return round(total_days / 365.25, 2)

    def _extract_companies(self, doc: spacy.tokens.Doc) -> list:
        companies = set()
        non_company_keywords = {
            "iso", "erp", "mrp", "$", "salary", "wage", "compensation", "program",
            "award", "scholarship", "prize", "honor", "grant", "fund", "£", "€"
        }

        # First pass: extract ORG entities with context awareness
        for ent in doc.ents:
            if ent.label_ == "ORG":
                comp = ent.text.strip()

                # Skip if contains digits or non-company keywords
                if re.search(r'\d', comp) or any(kw in comp.lower() for kw in non_company_keywords):
                    continue

                # Check context: Is it followed by a location (GPE) or date?
                has_context = False

                # Look for nearby GPE entities
                for other_ent in doc.ents:
                    if other_ent.label_ == "GPE" and abs(other_ent.start - ent.end) < 10:
                        has_context = True
                        break

                # Look for date patterns nearby
                sent = ent.sent.text if hasattr(ent, 'sent') else doc.text[
                                                                  max(0, ent.start_char - 100):min(len(doc.text),
                                                                                                   ent.end_char + 100)]
                if re.search(r'\b\d{4}\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b', sent):
                    has_context = True

                # Validate by checking for common suffixes or title case
                if (comp == comp.title() or any(
                        comp.lower().endswith(suffix) for suffix in self.company_suffixes)) and (
                        has_context or len(comp.split()) > 1):
                    companies.add(comp)

        # Second pass: use pattern matching for company-like phrases
        company_patterns = [
            r'(?:at|with|for)\s+([A-Z][A-Za-z\s]+(?:Inc|LLC|Corp|Co|Ltd)?)',
            r'(?:joined|worked\s+at)\s+([A-Z][A-Za-z\s]+)',
            r'([A-Z][A-Za-z0-9\s]+(?:Inc|LLC|Corp|Co|Ltd))'
        ]

        for pattern in company_patterns:
            for match in re.finditer(pattern, doc.text):
                company_name = match.group(1).strip()
                if not any(kw in company_name.lower() for kw in non_company_keywords):
                    companies.add(company_name)

        return sorted(companies)

    def _extract_positions(self, text: str, doc: spacy.tokens.Doc) -> list:
        """
        Enhanced position extraction using multiple strategies:
        1. Entity recognition for job titles
        2. Contextual clues around ORG entities and date ranges
        3. Multi-part title recognition
        4. Specific tagging for internships, volunteer roles, etc.
        """
        positions = []
        title_keywords = set(self.job_title_keywords)

        # Extract sentences or lines likely to be experience entries
        # Either process by sentences or split by newlines
        experience_chunks = []
        for sent in doc.sents:
            sent_text = sent.text.strip()
            # Check if sentence has company or date indicators
            if (any(ent.label_ == "ORG" for ent in sent.ents) or
                    re.search(r'\b\d{4}\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b', sent_text)):
                experience_chunks.append(sent)

        # If no sentences were identified, try splitting by newlines
        if not experience_chunks:
            for line in text.splitlines():
                line = line.strip()
                if line and re.search(r'\b\d{4}\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b', line):
                    experience_chunks.append(line)

        # Process each chunk to extract position titles
        for chunk in experience_chunks:
            chunk_text = chunk.text if hasattr(chunk, 'text') else chunk

            # Strategy 1: Look for job titles near ORG entities
            if hasattr(chunk, 'ents'):
                for ent in chunk.ents:
                    if ent.label_ == "ORG":
                        # Look for title keywords before or after the company
                        for i in range(max(0, ent.start - 7), min(ent.end + 7, len(doc))):
                            if i == ent.start or i == ent.end:
                                # Skip the entity itself
                                continue

                            token = doc[i]
                            if token.text.lower() in title_keywords:
                                # Found a title keyword, extract the surrounding phrase
                                start_idx = i
                                end_idx = i + 1

                                # Expand backward to get multi-part titles
                                while start_idx > 0 and (doc[start_idx - 1].is_alpha and doc[start_idx - 1].is_title):
                                    start_idx -= 1

                                # Expand forward
                                while end_idx < len(doc) and (doc[end_idx].is_alpha and not doc[end_idx].is_punct):
                                    end_idx += 1

                                title = doc[start_idx:end_idx].text.strip()

                                # Check if it's a legitimate title (not too long, contains keywords)
                                if len(title.split()) <= 5 and any(kw in title.lower() for kw in title_keywords):
                                    positions.append(title)
                                    break

            # Strategy 2: Pattern matching for common position formats
            position_patterns = [
                # Position at Company
                r'([A-Z][A-Za-z\s]+?(?:' + '|'.join(self.job_title_keywords) + r'))\s+(?:at|with|for)\s+([A-Za-z\s]+)',

                # Position (Company)
                r'([A-Z][A-Za-z\s]+?(?:' + '|'.join(self.job_title_keywords) + r'))\s*\([^)]+\)',

                # Company - Position
                r'([A-Z][A-Za-z\s]+)\s*[-–|]\s*([A-Z][A-Za-z\s]+?(?:' + '|'.join(self.job_title_keywords) + r'))'
            ]

            for pattern in position_patterns:
                for match in re.finditer(pattern, chunk_text):
                    position = match.group(1).strip()
                    # Clean the position text
                    position = self._clean_position_text(position)
                    if position and len(position.split()) <= 5:
                        positions.append(position)

        # Strategy 3: Line-by-line scanning for job titles
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue

            # Check for capitalized job titles
            line_lower = line.lower()
            if any(kw in line_lower for kw in title_keywords):
                # Try to extract the job title portion
                for kw in title_keywords:
                    if kw in line_lower:
                        idx = line_lower.find(kw)
                        start_idx = max(0, idx - 20)  # Look up to 20 chars before keyword
                        end_idx = min(len(line), idx + len(kw) + 20)  # And 20 chars after

                        # Extract and clean potential title
                        potential_title = line[start_idx:end_idx]

                        # If it contains a comma, take just the part before/after the comma
                        if ',' in potential_title:
                            parts = potential_title.split(',')
                            # Use the part containing the keyword
                            for part in parts:
                                if kw in part.lower():
                                    potential_title = part
                                    break

                        potential_title = self._clean_position_text(potential_title)

                        # Only add if it's reasonable length and not already captured
                        if potential_title and len(potential_title.split()) <= 5:
                            positions.append(potential_title)

        # Strategy 4: Tag special roles (internships, volunteer positions)
        tagged_positions = []
        special_role_tags = {
            "intern": "internship",
            "volunteer": "volunteer",
            "trainee": "training",
            "contract": "contract",
            "fellow": "fellowship"
        }

        for position in positions:
            position_lower = position.lower()
            for tag_key, tag_value in special_role_tags.items():
                if tag_key in position_lower:
                    tagged_positions.append({"title": position, "type": tag_value})
                    break
            else:
                tagged_positions.append({"title": position, "type": "regular"})

        # Get unique positions
        unique_positions = []
        seen_titles = set()

        for pos in tagged_positions:
            title = pos["title"]
            if title.lower() not in seen_titles:
                seen_titles.add(title.lower())
                unique_positions.append(pos)

        # Convert back to simple list if needed
        return [pos["title"] for pos in unique_positions]

    def _clean_position_text(self, position: str) -> str:
        """Clean position text by removing monetary values and extra characters."""
        # Remove any salary/monetary information
        position = re.sub(r'\$\d+[,\d]*\.?\d*', '', position)
        # Remove extra spaces
        position = re.sub(r'\s+', ' ', position).strip()
        # Remove trailing punctuation
        position = re.sub(r'[,\.]+$', '', position).strip()
        return position

    def _extract_leadership_positions(self, text: str) -> set:
        """Extract leadership positions from club/organization descriptions."""
        leadership_positions = set()

        # Look for leadership roles in organizations
        leadership_patterns = [
            r'([A-Z][A-Za-z\s]*(?:' + '|'.join(self.leadership_keywords) + r'))\s+(?:of|for)\s+([A-Z][A-Za-z\s]+)',
            r'([A-Z][A-Za-z\s]+)\s+([A-Z][A-Za-z\s]*(?:' + '|'.join(self.leadership_keywords) + r'))'
        ]

        for pattern in leadership_patterns:
            for match in re.finditer(pattern, text):
                role = match.group(1).strip()
                if role and not role.isdigit() and len(role.split()) <= 5:
                    leadership_positions.add(self._clean_position_text(role))

        return leadership_positions

    def parse(self, experience_text: str) -> dict:
        """
        Parse experience section to extract:
        - Total years of experience (with overlapping periods handled correctly)
        - List of companies
        - List of positions including leadership roles
        - Tagged special roles like internships
        """
        doc = self.nlp(experience_text)
        date_ranges = self._extract_date_ranges(experience_text)
        total_years = self._calculate_total_years(date_ranges)
        companies = self._extract_companies(doc)
        positions = self._extract_positions(experience_text, doc)

        # Extract leadership positions
        leadership_roles = self._extract_leadership_positions(experience_text)

        # Extract internships specifically
        internships = [p for p in positions if "intern" in p.lower()]

        return {
            "total_years": total_years,
            "companies": companies,
            "positions": positions,
            "leadership_roles": list(leadership_roles),
            "internships": internships,
            "date_ranges": [{
                "start": dr["start"].isoformat() if dr["start"] else None,
                "end": dr["end"].isoformat() if isinstance(dr["end"], datetime) else dr["end"],
                "text": dr["text"]
            } for dr in date_ranges]
        }